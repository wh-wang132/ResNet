#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

context of ONNX opset version.

"""


class OpsetContext:
    """ singleton class for opset version"""
    _instance = None

    def __new__(cls, *args, **kw):
        if cls._instance is None:
            cls._instance = object.__new__(cls, *args, **kw)
        return cls._instance

    def set_version(self, opset_version):
        """ setter of field _opset_version"""
        self._opset_version = opset_version

    def get_version(self):
        """ getter of field _opset_version"""
        if not hasattr(self, '_opset_version'):
            raise ValueError(
                "OpsetContext's opset_version field has not been set yet.")
        return self._opset_version
