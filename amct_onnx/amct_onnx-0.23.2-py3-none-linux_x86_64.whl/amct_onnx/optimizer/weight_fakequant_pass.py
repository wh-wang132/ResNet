#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fakequant weight from int8 to int9.

"""
import numpy as np

from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.vars import QUANTIZABLE_TYPES
from amct_onnx.utils.weight_quant_api import get_deconv_group
from amct_onnx.utils.weight_quant_api import adjust_deconv_weight_shape
from amct_onnx.common.utils.vars_util import RNN_LAYER_TYPE

WEIGHT_FAKEQUANT_DONE = 'weights_fakequant_done'


class WeightFakequantPass(BaseFusionPass):
    """
    Function: Fakequant weight from int8 to int9
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: init object
        Parameter:
            records: dict including quant factors such as scale_w
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records


    def do_pass(self, graph, object_node):
        """
        Function: Do actual quantization and node's weight is changed to int9.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        if object_node.type in RNN_LAYER_TYPE:
            self.dequant_weight(graph, object_node)
            self.dequant_weight(graph, object_node, True)
            return
        weight_node = QuantOpInfo.get_weight_node(object_node)
        # check if current weights is reused, then skip do fake quantize
        if weight_node.has_attr(WEIGHT_FAKEQUANT_DONE):
            return
        weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
        weights_helper = TensorProtoHelper(weight_tensor, model_path=weight_node.model_path)
        # get data
        int8_weight = weights_helper.get_data()
        if object_node.type == 'ConvTranspose' and get_deconv_group(object_node) > 1:
            int8_weight = adjust_deconv_weight_shape(object_node, int8_weight)
            trans_axes = (1, 0, 2, 3)
            int8_weight = np.transpose(int8_weight, trans_axes[:len(int8_weight.shape)])
        weights_helper.clear_data()

        weight_offset = self.records.get(object_node.name).get('weight_offset')
        int9_weight = int8_weight.astype(np.float32) - \
                      weight_offset.astype(np.float32)
        if object_node.type == 'ConvTranspose' and get_deconv_group(object_node) > 1:
            trans_axes = (1, 0, 2, 3)
            int9_weight = np.transpose(int9_weight, trans_axes[:len(int8_weight.shape)])
            int9_weight = adjust_deconv_weight_shape(object_node, int9_weight)
        int9_weight = int9_weight.reshape([-1])

        weights_helper.set_data(int9_weight, 'FLOAT', graph=graph)
        # set weights fake quantize done flag
        weight_node.set_attr(WEIGHT_FAKEQUANT_DONE, True)

        LOGGER.logd("Fakequant weight from int8 to int9 for layer '{}' " \
            "success!".format(object_node.name), 'WeightFakequantPass')

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be quantized in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type == "AveragePool":
            return False
        if node.type not in QUANTIZABLE_TYPES:
            return False

        if node.name not in self.records:
            return False

        # check whether node that has two inputs
        if node.has_attr(ATTR_NODE_TWO_INPUTS) and node.get_attr(ATTR_NODE_TWO_INPUTS):
            return False
        return True

    def dequant_weight(self, graph, object_node, is_recurrence_weight=False):
        """
        Function: dequant weight of rnn node to convert it to float32
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        if not is_recurrence_weight:
            weight_node = QuantOpInfo.get_weight_node(object_node)
            scale = self.records.get(object_node.name).get('weight_scale')
            offset = self.records.get(object_node.name).get('weight_offset')
        else:
            weight_node = QuantOpInfo.get_recurrence_weight_node(object_node)
            scale = self.records.get(object_node.name).get('recurrence_weight_scale')
            offset = self.records.get(object_node.name).get('recurrence_weight_offset')
        # check if current weights is reused, then skip do fake quantize
        if weight_node.has_attr(WEIGHT_FAKEQUANT_DONE):
            return

        weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
        weight_helper = TensorProtoHelper(weight_tensor, model_path=weight_node.model_path)
        weight = weight_helper.get_data().astype(np.float32)
        weight_helper.clear_data()

        if weight.shape[1] != scale.size:
            scale = np.repeat(scale, weight.shape[1] // scale.size)
            scale = scale.reshape(1, scale.size, 1)
            offset = np.repeat(offset, weight.shape[1] // offset.size)
            offset = offset.reshape(1, offset.size, 1)

        # Dequant w to fp32 to introduce quant error
        dtype = 'FLOAT'
        weight = (weight - offset) * scale.astype(np.float32)
        if self.records.get(object_node.name).get('op_data_type') == 'FLOAT16':
            weight = weight.astype(np.float16)
            dtype = 'FLOAT16'
        weight_helper.set_data(weight.reshape(-1), dtype, graph=graph)
        weight_node.set_attr(WEIGHT_FAKEQUANT_DONE, True)
