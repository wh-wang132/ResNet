#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Fusion quant_layers that from same input and have same scale and offset

"""
import numpy as np

from amct_onnx.utils.log import LOGGER
from amct_onnx.common.utils.attrs_list import ATTR_NODE_EQUIVALENT_OBJECT_LAYER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass


class QuantFusionPass(BaseFusionPass):
    """
    Function: Fusion quant_layers that from same input and have
              same scale and offset
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        """
        Function: Init QuantFusionPass object
        Parameters: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.records = records

    @staticmethod
    def find_same_quant_node(records, quant_node_list):
        """find quant node with same scale and offset"""
        fusional_quant_nodes = {}
        for node in quant_node_list:
            if not node.has_attr('object_node'):
                continue
            name = node.get_attr('object_node')
            scale_d = records.get(name).get('data_scale')
            offset_d = records.get(name).get('data_offset')
            act_type = records.get(name).get('act_type', 'INT8')
            encode_id = QuantFusionPass.encode_scale_offset(scale_d, offset_d) + act_type
            if encode_id not in fusional_quant_nodes:
                fusional_quant_nodes[encode_id] = [node]
            else:
                fusional_quant_nodes[encode_id].append(node)
        return fusional_quant_nodes

    @staticmethod
    def encode_scale_offset(scale, offset):
        """encode scale and offset to unique key"""
        float_scale = np.float32(scale)
        int32_offset = np.int32(offset)
        uint32_scale = np.frombuffer(float_scale, np.uint32)
        uint32_offset = np.frombuffer(int32_offset, np.uint32)

        encode_result = np.uint64(0)
        encode_result = np.uint64(uint32_scale) << np.uint32(32) | np.uint64(
            uint32_offset)

        return str(encode_result)

    def match_pattern(self, node):
        """
        Function: Find node that have multiple output quant layer
        Parameters: node: node in graph
        Return: True: node that need to do quant layer fusion operation
        """
        for out_anchor in node.output_anchors:
            quant_layer_num = 0
            for peer_in_anchor in out_anchor.get_peer_input_anchor():
                if peer_in_anchor.node.type == 'AscendQuant':
                    quant_layer_num += 1
            if quant_layer_num > 1:
                return True

        return False

    def do_pass(self, graph, object_node):
        """
        Function: Do quant layer fusion operation.
        Parameters: graph: graph that contains object node
                    object_node: node to process
        Return: None
        """
        for out_anchor in object_node.output_anchors:
            # record one out_anchor's all consumer quant node
            quant_node_list = []
            for peer_in_anchor in out_anchor.get_peer_input_anchor():
                if peer_in_anchor.node.type == "AscendQuant":
                    quant_node_list.append(peer_in_anchor.node)
            # record quant layer with same scale and offset
            fusional_quant_nodes = self.find_same_quant_node(
                self.records, quant_node_list)
            # do quant fusion
            for _, nodes in fusional_quant_nodes.items():
                if len(nodes) < 2:
                    continue
                # retain first quant node, remove the rest
                if nodes[0].has_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER):
                    nodes[0].set_attr(ATTR_NODE_EQUIVALENT_OBJECT_LAYER, '')
                for node in nodes[1:]:
                    # remove input edge at first
                    graph.remove_edge(object_node, out_anchor.index, node, 0)
                    # relink from node -> consumer to first_node -> consumer
                    node_output = node.get_output_anchor(0)
                    peers = node_output.get_peer_input_anchor().copy()
                    for peer_in_anchor in peers:
                        dst_node = peer_in_anchor.node
                        dst_anchor_index = peer_in_anchor.index
                        graph.remove_edge(node, 0, dst_node, dst_anchor_index)
                        graph.add_edge(nodes[0], 0, dst_node, dst_anchor_index)
                    graph.remove_node(node)
                    LOGGER.logd("Remove node {} from graph".format(node.name),
                                'QuantFusionPass')

        LOGGER.logd('Do fusion same quant layer from "{}" success!'.format(
            object_node.name), 'QuantFusionPass')
