#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Insert joint weights quantization pass.

"""


import numpy as np
from google.protobuf import text_format
from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.configuration.check import check_kernel_shape
from amct_onnx.configuration.check import _check_dilation
from amct_onnx.configuration.check import _check_group
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.utils.weight_quant_api import weight_calibration_np
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.common.utils.record_file_operator import \
    record_weights_scale_offset
from amct_onnx.proto import scale_offset_record_pb2

from amct_onnx.utils.vars import AMCT_OPERATIONS
from amct_onnx.optimizer.weight_calibration import CALIBRATION_DONE_FLAG
ELTWISE_OPTIMIZABLE_TYPES = ['Conv']
SUPPORTED_BYPASS_TYPES = ['Relu']
QUANTIZABLE_TYPES = ['Conv', 'Gemm', 'MatMul']
ELTWISE_OPTIMIZER_DONE_FLAG = 'eltiwse_optimizer_done'


def check_eltwise_opt_type(node):
    """
    Function: check if node can be eltwise optimized or not.
    """
    # check type, only support Conv for now
    if node.type not in ELTWISE_OPTIMIZABLE_TYPES:
        return False
    if node.name not in Configuration().get_quant_config():
        return False
    # Check only conv that single output to Eltwise can do union quantize
    if len(node.get_output_anchor(0).get_peer_input_anchor()) != 1:
        return False
    # Check Conv attribute
    if node.type == 'Conv':
        # must be conv2D or conv3D
        if not check_kernel_shape(node, [2, 3]):
            return False
        # group & dilation must be 1
        if not _check_dilation(node, ['1', [1, 1], [1, 1, 1]]) or not _check_group(node, ['1', 1]):
            return False
    return True


def is_quant_params_same(node_names):
    """
    Function: check whether the input quant params the same
    """
    # get weights' information for quantization
    if len(node_names) <= 1:
        return True
    head_node_name = node_names[0]

    head_layer_config = Configuration().get_layer_config(
        head_node_name)
    head_wts_param = head_layer_config.get('weight_quant_params')
    head_act_param = head_layer_config.get('activation_quant_params')

    for node_name in node_names[1:]:
        layer_config = Configuration().get_layer_config(node_name)
        wts_param = layer_config.get('weight_quant_params')
        act_param = layer_config.get('activation_quant_params')
        # if param not the same skip this pass
        if head_wts_param != wts_param or head_act_param != act_param:
            LOGGER.logi('Unable to do eltwise optimize layer {} and {} ' \
                        ' with different quant params'.format( \
                        head_node_name, \
                        node_name),
                        'AddOptWeightsCalibrationPass')
            return False
    return True


def _add_union_quant_node(node, union_list):
    """
    Function: Add node that can do union quantize
    """
    if not check_eltwise_opt_type(node):
        return False
    if not union_list:
        union_list.append(node.name)
        return True
    head_node_name = union_list[0]
    if not union_list.count(node.name) and \
        is_quant_params_same([head_node_name, node.name]):
        union_list.append(node.name)
        return True
    return False


class AddOptWeightsCalibrationPass(BaseFusionPass):
    """
    Function: the pass to quantize eltwsie + conv2d by Calibration.
    APIs: set_up, tear_down, match_pattern, do_pass
    """
    def __init__(self):
        BaseFusionPass.__init__(self)
        self.records = scale_offset_record_pb2.ScaleOffsetRecord()
        self.record_file_path = Configuration().get_record_file_path()

    @staticmethod
    def match_pattern(node, done_attr, do_eltwise_quant=False):
        """
        Function: match pattern that can do eltwize optimizer: start with eltwise
        that has two conv input, end to eltwise node that all output node
        can be quantized, if one eltwise has unquantifiable output (except
        eltwise node) then whole pattern cannot do optimizer.
        """
        if node.type != 'Add':
            return None

        is_support, _ = AddOptWeightsCalibrationPass._check_eltwise(node)
        if not is_support:
            LOGGER.logd('Add node "{}" not support do optimize'.format(
                node.name))
            return None

        # Check input node to eltwise, must all be quantizable conv node
        if not AddOptWeightsCalibrationPass._check_input_type(node):
            return None

        input_nodes = AddOptWeightsCalibrationPass._get_eltwise_input_nodes(node)
        if not is_quant_params_same([input_node.name for input_node in input_nodes]):
            return None
        return AddOptWeightsCalibrationPass._match_pattern_kernel(
            node, done_attr, do_eltwise_quant)

    @staticmethod
    def _packet_union_quantize_conv_weights(graph, union_list, data_record):
        """
        Function: packet all need do union quantize conv layers' weights to 1 concated numpy array
        """
        # Set first node as base node to concate
        head_node_name = union_list[0]
        head_node = graph.get_node_by_name(head_node_name)
        head_node.set_attr(CALIBRATION_DONE_FLAG, True)
        # get first node weights
        head_weights_node = QuantOpInfo.get_weight_node(head_node)
        head_weights_tensor = QuantOpInfo.get_node_tensor(head_weights_node)
        head_weights_helper = TensorProtoHelper(head_weights_tensor, model_path=head_weights_node.model_path)
        head_weights = head_weights_helper.get_data().copy()
        head_shape = head_weights.shape
        head_weights_helper.clear_data()
        data_record[head_node_name] = {
            'weights_helper': head_weights_helper,
            'shape': head_shape
        }

        concated_weights = head_weights.reshape(
            head_shape[0], head_shape[1] * head_shape[2] * head_shape[3])

        for node_name in union_list[1:]:
            current_node = graph.get_node_by_name(node_name)
            current_node.set_attr(CALIBRATION_DONE_FLAG, True)
            # current_blob_info contains: current_blob, current_shape,
            #                             current_dtype, current_data
            current_weights_node = QuantOpInfo.get_weight_node(current_node)
            current_weights_tensor = QuantOpInfo.get_node_tensor(current_weights_node)
            current_weights_helper = TensorProtoHelper(current_weights_tensor,
                                                       model_path=current_weights_node.model_path)
            current_weights = current_weights_helper.get_data().copy()
            current_shape = current_weights.shape
            current_weights_helper.clear_data()
            data_record[current_node.name] = {
                'weights_helper': current_weights_helper,
                'shape': current_shape
            }

            current_weights = current_weights.reshape(
                current_shape[0], current_shape[1] * current_shape[2] * current_shape[3])

            if not is_quant_params_same([head_node_name, node_name]):
                LOGGER.logi('Union quantize node {} and {} params not ' \
                    'same'.format(head_node_name, node_name))
                return None

            if concated_weights.shape[0] != current_weights.shape[0]:
                LOGGER.logi('Union weights {}{} shape diff from {}'.format(
                    node_name, current_weights.shape, concated_weights.shape))
                return None
            concated_weights = np.concatenate(
                (concated_weights, current_weights), axis=1)
        return concated_weights

    @staticmethod
    def _check_input_type(node):
        """
        Function: Check input node to eltwise, must all be quantizable conv node
        Parameters:
        input_nodes: list of input nodes
        """
        input_nodes = AddOptWeightsCalibrationPass._get_eltwise_input_nodes(node)
        for input_node in input_nodes:
            if not check_eltwise_opt_type(input_node):
                LOGGER.logd('Exist not support input node "{}" to "{}"'.format(
                    input_node.name, node.name))
                return False
        return True

    @staticmethod
    def _check_requants16_optimze(input_nodes, union_list):
        """
        Function: If all input_nodes is Convolution, then check if one from eltwise,
        then should add another node.
        """
        peer_output_nodes = []
        for input_node in input_nodes:
            if input_node.type != 'Conv':
                return
            input_anchor = input_node.get_input_anchor(0)
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            peer_output_nodes.append(peer_output_anchor.node)

        for index, peer_node in enumerate(peer_output_nodes):
            if peer_node.type in SUPPORTED_BYPASS_TYPES:
                input_anchor = peer_node.get_input_anchor(0)
                grand_peer_anchor = input_anchor.get_peer_output_anchor()
                grand_peer_node = grand_peer_anchor.node
                peer_output_nodes[index] = grand_peer_node

        for peer_output_node in peer_output_nodes:
            AddOptWeightsCalibrationPass._check_requants16_optimze_kernel(
                peer_output_node, input_nodes, union_list)

    @staticmethod
    def _check_requants16_optimze_kernel(producer_node, input_nodes, union_list):
        """
        Function: Add requants16 optimze union quant node to union_list
        """
        if producer_node.type in ('Add', 'MaxPool'):
            output_anchor = producer_node.get_output_anchor(0)
            if len(output_anchor.get_peer_input_anchor()) == 1:
                consumer_node = output_anchor.get_peer_input_anchor()[0].node
                if consumer_node.type in SUPPORTED_BYPASS_TYPES:
                    output_anchor = consumer_node.get_output_anchor(0)
            for peer_input_anchor in output_anchor.get_peer_input_anchor():
                consumer_node = peer_input_anchor.node
                if consumer_node not in input_nodes:
                    _add_union_quant_node(consumer_node, union_list)

    @staticmethod
    def _match_pattern_kernel(head_node, done_attr, do_eltwise_quant):
        """
        Function: start do pattern search
        """
        union_list = []
        candidate_eltwise = [head_node]
        while candidate_eltwise:
            current_node = candidate_eltwise.pop(0)
            is_support, next_add = \
                AddOptWeightsCalibrationPass._check_eltwise(current_node)
            if not is_support:
                return None
            input_nodes = \
                AddOptWeightsCalibrationPass._get_eltwise_input_nodes(
                    current_node)
            if not union_list and do_eltwise_quant:
                AddOptWeightsCalibrationPass._check_requants16_optimze(
                    input_nodes, union_list)

            for input_node in input_nodes:
                # If input node exise eltwise or equivalent node, need
                # check whether it be unioned
                if input_node.type == 'Add' or \
                    input_node.type in SUPPORTED_BYPASS_TYPES:
                    if not input_node.has_attr(done_attr):
                        LOGGER.logi('Exist unsupport pattern start with "{}" because layer "{}"'.format( \
                                    head_node.name, input_node.name))
                        return None
                elif not _add_union_quant_node(input_node, union_list):
                    return None
            current_node.set_attr(done_attr, True)
            output_anchor = current_node.get_output_anchor(0)
            for peer_anchor in output_anchor.get_peer_input_anchor():
                if peer_anchor.node.type in SUPPORTED_BYPASS_TYPES:
                    peer_anchor.node.set_attr(done_attr, True)
            candidate_eltwise.extend(next_add)
        return union_list

    @staticmethod
    def _get_eltwise_input_nodes(node_add):
        """
        Function: Get and return eltwise node's two input node
        """
        # get left input node
        eltwise_input_nodes = []
        for input_anchor in node_add.input_anchors:
            peer_output_anchor = input_anchor.get_peer_output_anchor()
            input_node = peer_output_anchor.node
            eltwise_input_nodes.append(input_node)

        return eltwise_input_nodes

    @staticmethod
    def _check_eltwise_property(node_add):
        """
        Function:Check basic eltwise layer's info
        """
        # Add must be multi input and single output
        if len(node_add.input_anchors) < 2:
            raise RuntimeError('Add node at least have two output, but ' \
                '{} has {}'.format(node_add.name, \
                    len(node_add.input_anchors)))
        if len(node_add.output_anchors) != 1:
            raise RuntimeError('Add node can only have one output, but ' \
                '{} has {}'.format(node_add.name, \
                    len(node_add.output_anchors)))
        return True

    @staticmethod
    def _check_eltwise(node_add):
        """
        Function: Check if eltiwse node exist unquantifiable output (except
        eltwise node)
        """
        if not AddOptWeightsCalibrationPass._check_eltwise_property(node_add):
            LOGGER.logd('Add {} not support do S16 optimize.'.format(node_add.name))
            return False, None
        # Check eltwise layer's output node
        next_add = []
        output_anchor = node_add.get_output_anchor(0)
        peer_anchors = output_anchor.get_peer_input_anchor() # consumers of Add
        # If Add output to bypass node(ReLU), Check bypass node's output
        if len(peer_anchors) == 1 and peer_anchors[0].node.type in SUPPORTED_BYPASS_TYPES:
            peer_node = peer_anchors[0].node
            output_anchors = peer_node.output_anchors
            if len(output_anchors) != 1:
                raise RuntimeError('Node "{}" can only have one output,' \
                    ' but has {}'.format(peer_node.name, \
                        len(peer_node.output_anchors)))
            peer_anchors = output_anchors[0].get_peer_input_anchor()
        found_quant_node = False
        for peer_anchor in peer_anchors:
            # If consumer node contains eltwise, add it to infected list,
            # but when consumer have "done" flag, means it already infected
            # by others, skip it.
            peer_node = peer_anchor.node
            if peer_node.type == 'Add':
                next_add.append(peer_node)
            elif peer_node.type in QUANTIZABLE_TYPES and peer_node.name in Configuration().get_quant_config():
                # Add optimize need have quantize node after it, but
                # Pooling is not supported.
                found_quant_node = True
            # If eltwise's consumer contains unsupport layer, then
            # all infected elwise cannot do union quantize.
            elif peer_node.type not in AMCT_OPERATIONS and not peer_node.has_attr('produce_by_amct'):
                LOGGER.logd('Exist not support layer "{}" after Add ' \
                            '"{}"'.format(peer_node.name, \
                            node_add.name))
                return False, None
        if not found_quant_node:
            LOGGER.logd('Cannot find quantize node after Add:{}'.format(
                node_add.name))
            return False, None
        return True, next_add

    def set_up(self):
        """
        Function: read the scale and offset from Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, 'r') as file_record_read:
            pbtxt_string = file_record_read.read()
            text_format.Merge(pbtxt_string, self.records)

    def tear_down(self):
        """
        Function: write the scale and offset to Configuration's file.
        Inputs: None
        Returns: None
        """
        with open(self.record_file_path, "w") as file_record_read:
            file_record_read.write(text_format.MessageToString(
                self.records, as_utf8=True))

    def do_pass(self, graph, union_list):
        """
        Function: apply weights joint-quant to the graph for ops in union_list
        Parameters:
        graph: the model graph IR
        union_list: the op names's list, which will apply joint-quant
        Return: None
        """
        # find weights_blob
        if len(union_list) <= 1:
            return

        data_record = {}
        concated_weights = self._packet_union_quantize_conv_weights(
            graph, union_list, data_record)
        if concated_weights is None:
            return

        concated_shape = concated_weights.shape
        concated_weights = concated_weights.reshape(
            [concated_shape[0], 1, 1, concated_shape[1]])
        # Get first node's weights quantize parameter as whole concated
        # weights' quantize parameter
        layer_config = Configuration().get_layer_config(union_list[0])
        wts_param = layer_config.get('weight_quant_params')
        scale, offset = weight_calibration_np(concated_weights, wts_param)

        concated_weights.shape = concated_shape
        split_index = 0
        for node_name in union_list:
            record_weights_scale_offset(self.records, node_name, scale, offset)
            weights_shape = data_record[node_name]['shape']
            current_split_index = weights_shape[1] * weights_shape[2] * weights_shape[3]

            data_record[node_name]['weights_helper'].set_data(
                concated_weights[:, split_index:(split_index + current_split_index)].flatten())
            split_index += current_split_index

        LOGGER.logi('Do layers {} union weights calibration success.'.format( \
                    union_list), 'AddOptWeightsCalibrationPass')

    def run(self, graph):
        """
        Function: execute AddOptWeightsCalibrationPass
        Parameters:
        graph: the model graph IR
        Return: None
        """
        self.set_up()
        union_lists = []
        for node in graph.nodes:
            union_list = self.match_pattern(node, '{}_{}'.format(
                ELTWISE_OPTIMIZER_DONE_FLAG, node.index))
            if union_list is not None:
                union_lists.append(union_list)
        for union_list in union_lists:
            self.do_pass(graph, union_list)
        self.tear_down()
