#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

replace QuantizeLinear to AscendQuant in the graph

"""

from amct_onnx.common.utils.util import check_scale
from amct_onnx.common.utils.vars_util import INT8
from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.optimizer.insert_quant_pass import construct_quant_node
from amct_onnx.optimizer.delete_fake_quant_node_pass import get_scale_offset


class ReplaceQuantizeLiearOnlyPass(BaseFusionPass):
    """
    Function: replace QuantizeLiear ops to AscendQuant with amct domain.
    APIs: match_pattern, do_pass
    """
    def __init__(self, graph):
        """
        Function: init object
        Parameter:
            graph: Graph
        Return: None
        """
        BaseFusionPass.__init__(self)
        self.graph = graph

    def match_pattern(self, node):
        """
        Function: Match pattern of node to be replaced in graph
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type not in ['QuantizeLinear']:
            return False

        if len(node.output_anchors) != 1:
            LOGGER.logd(
                "quantize linear output anchors {}, skip replacing".format(len(node.output_anchors)),
                'ReplaceQuantizeLiearOnlyPass')
            return False

        output_names = []
        for output in self.graph.net.graph.output:
            output_names.append(output.name)

        consumer = node.get_output_anchor(0).get_peer_input_anchor()[0].node
        if consumer.name not in output_names:
            LOGGER.logd(
                "quantize_linear's consumer is not output, skip replacing",
                'ReplaceQuantizeLiearOnlyPass')
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actually replace QuantizeLinear to AscendQuant.
        Parameters:
            graph: graph structure
            object_node: node to process
        Return: None
        """
        scale, offset, dst_type = get_scale_offset(object_node)
        if dst_type != INT8:
            raise RuntimeError("Invalid y_zero_point data type of node {}".format(object_node.name))
        check_scale(scale[0], object_node.name)

        producer = object_node.get_input_anchor(0).get_peer_output_anchor().node
        consumer = object_node.get_output_anchor(0).get_peer_input_anchor()[0].node

        quant_node_proto = construct_quant_node(
            inputs=[producer.name],
            outputs=[consumer.name],
            attrs={
                'scale': 1.0 / scale[0],
                'offset': offset[0],
                'quant_bit': 8
            },
            layer_name=object_node.name)

        # quantize linear only node has no object node
        quant_node = graph.add_node(quant_node_proto)

        producer_anchor = object_node.get_input_anchor(0).get_peer_output_anchor()
        graph.remove_edge(producer, producer_anchor.index, object_node, 0)
        graph.add_edge(producer, producer_anchor.index, quant_node, 0)

        consumer_anchors = object_node.get_output_anchor(0).get_peer_input_anchor().copy()
        for consumer_anchor in consumer_anchors:
            graph.remove_edge(object_node, 0, consumer, consumer_anchor.index)
            graph.add_edge(quant_node, 0, consumer, consumer_anchor.index)

        # remove constant nodes & quantize linear
        quant_scale_node = object_node.get_input_anchor(1).get_peer_output_anchor().node
        qaunt_offset_node = object_node.get_input_anchor(2).get_peer_output_anchor().node
        for node in [quant_scale_node, qaunt_offset_node]:
            if node.type == 'Constant':
                graph.remove_node(node)
            elif node.type == 'initializer':
                graph.remove_initializer(qaunt_offset_node)
        graph.remove_node(object_node)

        LOGGER.logd(
            'layer "{}" convert quantize_liner to AscendQuant success.'.format(object_node.name),
            'ReplaceQuantizeLiearOnlyPass')

