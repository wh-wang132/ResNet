#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2025. Huawei Technologies Co., Ltd. All rights reserved.
 
This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.
 
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0
 
Delete QuantizeLinear, DequantizeLinear nodes before Add in graph, and record scale/offset
"""
import numpy as np

from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.optimizer.delete_fake_quant_node_pass import get_scale_offset


class DeleteQuantizelinearDequantizelinearOfAddPass(BaseFusionPass):
    """
    Function: Delete QuantizeLinear, DequantizeLinear nodes before Add in graph, and record scale/offset
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        super().__init__()
        self.records = records

    @staticmethod
    def _is_perchannel(quantize_node):
        '''check pertensor'''
        scale_node = quantize_node.get_input_anchor(1).get_peer_output_anchor().node
        scale = QuantOpInfo.get_node_value(scale_node)
        if scale.size > 1:
            return True
        return False

    @staticmethod
    def _check_quant_dequant_params(quant_node, dequant_node):
        quant_scale, quant_offset, quant_dtype = get_scale_offset(quant_node)
        dequant_scale, dequant_offset, dequant_dtype = get_scale_offset(dequant_node)
        quant_scale = np.array(quant_scale)
        quant_offset = np.array(quant_offset)
        dequant_scale = np.array(dequant_scale)
        dequant_offset = np.array(dequant_offset)
        if quant_scale.shape != dequant_scale.shape or quant_offset.shape != dequant_offset.shape:
            LOGGER.loge(
                'The shapes of quantization information of node "{}" and node "{}" are inconsistent!'.format(
                    quant_node.name, dequant_node.name))
            raise ValueError(
                'The shapes of quantization information of node "{}" and node "{}" are inconsistent!'.format(
                    quant_node.name, dequant_node.name))

        if quant_dtype != dequant_dtype:
            LOGGER.loge('The data type of quantization information of node "{}" and node "{}" are '
                        'inconsistent!'.format(quant_node.name, dequant_node.name))
            raise ValueError('The data type of quantization information of node "{}" and node "{}" are '
                             'inconsistent!'.format(quant_node.name, dequant_node.name))
                
        if (quant_scale == dequant_scale).all() and (quant_offset == dequant_offset).all():
            return

        LOGGER.loge('The values of quantization information of node "{}" and node "{}" are inconsistent!'.format(
            quant_node.name, dequant_node.name))
        raise ValueError('The values of quantization information of node "{}" and node "{}" are inconsistent!'.format(
            quant_node.name, dequant_node.name))

    def match_pattern(self, node):
        """
        Function: Find node has fusion info in graph
        Parameters: node: node in graph
        Return: True: node that has info
                False: skip the node
        """
        if node.type != 'QuantizeLinear':
            return False
        consumers, _ = node.get_consumers(0)
        if len(consumers) != 1:
            return False

        consumer = consumers[0]
        if consumer.type != 'DequantizeLinear':
            return False
        consumers, _ = consumer.get_consumers(0)
        if len(consumers) != 1:
            return False

        consumer = consumers[0]
        if consumer.type != 'Add':
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: process object_node
        Parameters:
            object_node: matched node
        Return: None
        """
        if self._is_perchannel(object_node):
            LOGGER.loge("do not support perchannel quant of node {} to do qdq pass".format(object_node.name))
            raise ValueError("do not support perchannel quant of node {} to do qdq pass".format(object_node.name))

        producer, out_idx_producer = object_node.get_producer(0)
        dequantize_node_list, _ = object_node.get_consumers(0)
        dequantize_node = dequantize_node_list[0]
        add_node_list, in_idx_add = dequantize_node.get_consumers(0)
        add_node = add_node_list[0]

        self._check_quant_dequant_params(object_node, dequantize_node)
        scale, offset, dst_type = get_scale_offset(object_node)
        self.records.record_tensor_quant_scale_offset(add_node.ori_name+':'+str(in_idx_add[0]),
                                                        scale[0], offset[0], dst_type)
        
        DeleteQuantizelinearDequantizelinearOfAddPass.remove_qat_node(
            graph, add_node, object_node, dequantize_node, in_idx_add[0])
        LOGGER.logd(
            'layer "{}" delete quantizeliner + dequantizelinear before add success, and record scale offset ' \
            'in record file.'.format(object_node.name), 'DeleteQuantizelinearDequantizelinearOfAddPass')

    @staticmethod
    def remove_qat_node(graph, quantized_node, quantize_linear_node, dequantize_linear_node, input_index):
        """
        Remove quantization and dequantization node from the graph and reconnect relevant nodes.

        Parameters:
        graph: The computational graph object.
        quantized_node: The quantizatied node.
        quantize_linear_node: The QuantizeLinear node.
        dequantize_linear_node: The DequantizeLinear node.
        input_index: The input index.
        """
        delete_initializer = set()
        delete_node = set()
        input_anchors = quantize_linear_node._input_anchors[1:] + dequantize_linear_node._input_anchors[1:]
        for input_anchor in input_anchors:
            src_anchor = input_anchor.get_peer_output_anchor()
            if src_anchor.node.type == 'initializer':
                graph.remove_edge(src_anchor.node, src_anchor.index, input_anchor.node, input_anchor.index)
                delete_initializer.add(src_anchor.node)
            elif src_anchor.node.type == 'Constant':
                graph.remove_edge(src_anchor.node, src_anchor.index, input_anchor.node, input_anchor.index)
                delete_node.add(src_anchor.node)

        producer, out_idx_producer = quantize_linear_node.get_producer(0)
        graph.remove_edge(producer, out_idx_producer, quantize_linear_node, 0)
        graph.remove_edge(dequantize_linear_node, 0, quantized_node, input_index)
        graph.add_edge(producer, 0, quantized_node, input_index)

        for node in delete_node:
            graph.remove_node(node)
        for initializer in delete_initializer:
            graph.remove_initializer(initializer)

        graph.remove_node(quantize_linear_node)
        graph.remove_node(dequantize_linear_node)