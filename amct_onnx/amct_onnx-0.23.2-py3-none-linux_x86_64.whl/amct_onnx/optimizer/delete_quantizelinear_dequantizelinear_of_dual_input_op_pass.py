#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2025. Huawei Technologies Co., Ltd. All rights reserved.
 
This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.
 
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0
 
Delete QuantizeLinear, DequantizeLinear nodes before dual input op in graph, and record scale/offset

structure in graph:

Activation         Activation
      |                  |
QuantizeLinear     QuantizeLinear
      |                  |
DequantizeLinear   DequantizeLinear
      |                  |
      -------------------
               |
          QuantizedNode
"""
import numpy as np

from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.vars import CONVERT_QAT_DUAL_INPUT_QUANTIZABLE_TYPES
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.optimizer.delete_fake_quant_node_pass import get_scale_offset
from amct_onnx.optimizer.delete_fake_quant_node_pass import DeleteFakeQuantNodePass
from amct_onnx.optimizer.delete_quantizelinear_dequantizelinear_of_add_pass import \
    DeleteQuantizelinearDequantizelinearOfAddPass


class DeleteQuantizelinearDequantizelinearOfDualInputOpPass(BaseFusionPass):
    """
    Function: Delete QuantizeLinear, DequantizeLinear nodes before dual input operator in graph,
        and record scale/offset
    APIs: match_pattern, do_pass
    """
    def __init__(self, records):
        super().__init__()
        self.records = records

    def match_pattern(self, node):
        """
        Function: Find first quantizelinear node for dual input op
        Parameters: node: node in graph
        Return: True: node that has info
                False: skip the node
        """
        # step 1: node struct must be quantize-dequantize-node
        if node.type != 'QuantizeLinear':
            return False
        consumers, _ = node.get_consumers(0)
        if len(consumers) != 1:
            return False

        dequantize_node = consumers[0]
        if dequantize_node.type != 'DequantizeLinear':
            return False
        consumers, _ = dequantize_node.get_consumers(0)
        if len(consumers) != 1:
            return False

        quantized_node = consumers[0]
        if quantized_node.type not in CONVERT_QAT_DUAL_INPUT_QUANTIZABLE_TYPES:
            return False

        # step 2:do pass only when qdq is the first input of quantized node
        if quantized_node.get_producer(0)[0] != dequantize_node:
            return False

        # step 3:input in index 1 must be qdq for quantized node
        dequantized_node_idx_1 = quantized_node.get_producer(1)[0]
        if dequantized_node_idx_1.type != 'DequantizeLinear':
            return False
        consumers, _ = dequantized_node_idx_1.get_consumers(0)
        if len(consumers) != 1:
            return False

        quantized_node_idx_1 = dequantized_node_idx_1.get_producer(0)[0]
        if quantized_node_idx_1.type != 'QuantizeLinear':
            return False
        consumers, _ = quantized_node_idx_1.get_consumers(0)
        if len(consumers) != 1:
            return False

        # step 4: input in index 1 must not be const or initializer
        input_idx_1_node = quantized_node_idx_1.get_input_anchor(0).get_peer_output_anchor().node
        if input_idx_1_node.type in ['initializer', 'Constant']:
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: process object_node
        Parameters:
            object_node: matched node
        Return: None
        """
        # step 1: find qat node struct started from quantize linear
        dequantize_node_list, _ = object_node.get_consumers(0)
        dequantize_node_idx_0 = dequantize_node_list[0]

        quantized_node_list, _ = dequantize_node_idx_0.get_consumers(0)
        quantized_node = quantized_node_list[0]
        
        dequantize_node_idx_1, _ = quantized_node.get_producer(1)
        quantize_node_idx_1, _ = dequantize_node_idx_1.get_producer(0)
        
        # check matmul qat convert only support per-tensor
        DeleteFakeQuantNodePass.is_perchannel(object_node)
        DeleteFakeQuantNodePass.is_perchannel(quantize_node_idx_1)

        # step 2: record scale/offset for quantized node
        DeleteQuantizelinearDequantizelinearOfAddPass._check_quant_dequant_params(
            object_node, dequantize_node_idx_0)
        scale, offset, dst_type = get_scale_offset(object_node)
        if not (np.array(offset) == 0).all():
            raise ValueError(
                "Input quant only support symmetric quantize, {} offset is {}".format(quantized_node.name, offset))
        if dst_type not in ['INT8']:
            raise ValueError("Index 0 input only support INT8 quantization")
        self.records.record_activation_scale_offset(
                quantized_node.ori_name, scale[0], offset[0], dst_type)

        DeleteQuantizelinearDequantizelinearOfAddPass._check_quant_dequant_params(
            quantize_node_idx_1, dequantize_node_idx_1)
        scale, offset, dst_type = get_scale_offset(quantize_node_idx_1)
        if not (np.array(offset) == 0).all():
            raise ValueError(
                "Other quant only support symmetric quantize, {} offset is {}".format(quantized_node.name, offset))
        if dst_type not in ['INT8']:
            raise ValueError("Index 1 input only support INT8 quantization")
        self.records.record_weights_scale_offset(
                quantized_node.ori_name, scale, offset, dst_type)

        # step 3: remove qat node and relink input to quantized node
        DeleteQuantizelinearDequantizelinearOfAddPass.remove_qat_node(
            graph, quantized_node, object_node, dequantize_node_idx_0, 0)
        DeleteQuantizelinearDequantizelinearOfAddPass.remove_qat_node(
            graph, quantized_node, quantize_node_idx_1, dequantize_node_idx_1, 1)
        LOGGER.logd(
            'layer "{}" delete quantizeliner and dequantizelinear for matmul dual input success, '
            'and record scale offset in record file.'.format(object_node.name),
            'DeleteQuantizelinearDequantizelinearOfDualInputOpPass')
