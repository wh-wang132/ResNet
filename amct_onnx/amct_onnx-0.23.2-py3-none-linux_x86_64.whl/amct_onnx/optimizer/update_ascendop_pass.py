#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2023. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Update Ascend ops to fakeqaunt with amct domain.

"""
from amct_onnx.utils.log import LOGGER
from amct_onnx.optimizer.base_fusion_pass import BaseFusionPass
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.common.utils.onnx_node_util import AttributeProtoHelper
from onnx.onnx_pb import TensorProto


class UpdateAscendOpPass(BaseFusionPass):
    """
    Function: Update Ascend ops to fakeqaunt with amct domain.
    APIs: match_pattern, do_pass
    """
    def __init__(self, records=None):
        """
        Function: init object
        Parameter: None
        Return: None
        """
        BaseFusionPass.__init__(self)
        if records:
            self.records = records
        else:
            self.records = {}

    def match_pattern(self, node):
        """
        Function: Match the AscendQuant node
        Parameters: node: node in graph to be matched
        Return: True: matched
                False: mismatch
        """
        if node.type != 'AscendQuant':
            return False

        return True

    def do_pass(self, graph, object_node):
        """
        Function: Do actually replacing AscendQuant to fakeqaunt 'Quant'
            with onnx's ops
        Parameters: graph: graph structure
                    object_node: node to process
        Return: None
        """
        op_domain = 'amct.customop'
        ascend_nodes = set()
        ascend_nodes.add(object_node)
        consumers, _ = object_node.get_consumers(0)
        for consumer in consumers:
            if consumer.type == 'AscendAntiQuant':
                ascend_nodes.add(consumer)
                continue
            if consumer.type == 'Pad':
                quant_op = consumer.get_consumers(0)[0][0]
                dequant_op = quant_op.get_consumers(0)[0][0]
                ascend_nodes.add(dequant_op)
                continue
            if consumer.type == 'AveragePool':
                dequant_op = consumer.get_consumers(0)[0][0]
                ascend_nodes.add(dequant_op)
                continue
            if consumer.type == 'MatMul':
                bias_node = QuantOpInfo.get_bias_node(consumer)
                if consumer.has_attr(ATTR_NODE_TWO_INPUTS) and consumer.get_attr(ATTR_NODE_TWO_INPUTS):
                    dequant_op = consumer.get_consumers(0)[0][0]
                    if bias_node is not None:
                        dequant_op = dequant_op.get_consumers(0)[0][0]
                    ascend_nodes.add(dequant_op)
                    continue
                dequant_op = consumer.get_consumers(0)[0][0]
                if bias_node is not None:
                    dequant_op = dequant_op.get_consumers(0)[0][0]
                ascend_nodes.add(dequant_op)
                continue

            # dequnt node exists
            if len(consumer.output_anchors) > 0:
                dequant_op = consumer.get_consumers(0)[0][0]
                ascend_nodes.add(dequant_op)

        for consumer in consumers:
            if consumer.type == 'Pad':
                consumer = consumer.get_consumers(0)[0][0]
            if consumer.name in self.records.keys() and \
                self.records.get(consumer.name).get('op_data_type') == 'FLOAT16':
                op_domain = 'amct.customop.extfp16'
                break
        for node in ascend_nodes:
            self.clear_extra_attr(node, ['dtype'])
            node.proto.domain = op_domain
            LOGGER.logd("Update ascend op '{}' to do fake quant success!".
                format(node.name), 'ReplaceQuantPass')
        if self._check_graph_output(graph, consumers):
            self.clear_extra_attr(node, ['dtype'])
            node.proto.domain = 'amct.customop.extint8'

    def clear_extra_attr(self, node, attr_list):
        ''' clear extra attr from node proto '''
        for attr in node.proto.attribute:
            if attr.name in attr_list:
                node.proto.attribute.remove(attr)

    def _check_graph_output(self, graph, consumers):
        ''' check whether the node is output of graph'''
        if len(consumers) == 0:
            return True

        if consumers[0].type == 'graph_output':
            return True

        return False