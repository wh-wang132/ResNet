#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Generate json file that contains fusion layer infos

"""
from amct_onnx.proto import fusion_pb2
from amct_onnx.common.optimizer.gen_fusion_json_base \
    import GenFusionJsonBasePass


class GenFusionJsonPass(GenFusionJsonBasePass):
    """
    Function: Generate json file that contains fusion layer infos
    APIs: match_pattern, do_pass
    """
    def __init__(self):
        """
        Function: Init object
        Parameters: None
        Return: None
        """
        super().__init__(fusion_pb2)

    def do_pass(self, graph, object_node):
        """
        Funtion: add fusion info for object_node
        Parameters:
            graph: object_node's graph
            object_node: node to process
        """
        super().do_pass(graph, object_node)

        if graph.net.graph.HasField('name'):
            self._graph_name = graph.net.graph.name
