#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

graph checker and graph quirer

"""

import numpy as np

from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.vars import QUANTIZABLE_TYPES
from amct_onnx.utils.vars import INT16_QUANTIZABLE_TYPES
from amct_onnx.utils.vars import CONVERT_QAT_QUANTIZABLE_TYPES
from amct_onnx.utils.vars import AMCT_OPERATIONS
from amct_onnx.common.utils.onnx_node_util import AttributeProtoHelper
from amct_onnx.utils.quant_node import QuantOpInfo
from amct_onnx.capacity import CAPACITY
from amct_onnx.opset_utils.pad_utils import PadUtils
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.utils.vars import MATMUL_TWO_INPUT
from amct_onnx.utils.attrs_list import ATTR_NODE_TWO_INPUTS
from amct_onnx.utils.vars import QUANT_LAYER_SUFFIX
from amct_onnx.utils.vars import CONSTANT_NODE_TYPE
from amct_onnx.utils.vars import TENSOR_QUANTIZABLE_TYPES
from amct_onnx.common.utils.vars_util import RNN_SEQ_LENS_INDEX, RNN_H_INDEX
from amct_onnx.common.utils.vars_util import LSTM_C_INDEX, LSTM_P_INDEX
from amct_onnx.common.utils.vars_util import LSTM_OUTPUT_NUMS, GRU_OUTPUT_NUMS
from amct_onnx.common.utils.vars_util import RNN_LAYER_TYPE
from amct_onnx.common.utils.vars_util import LSTM_ATTRS_LIMIT_MAP, GRU_ATTRS_LIMIT_MAP
from amct_onnx.utils.vars import MATMUL_WEIGHT_DIMS


MODULE_NAME = 'Configuration'
HAS_WEIGHT_TYPE = ['Conv', 'Gemm', 'ConvTranspose', 'LSTM', 'GRU']


class GraphQuerier():
    '''provide some APIs to query the graph'''
    @staticmethod
    def get_name_type_dict(graph):
        '''get all layer name to type dict'''
        name_type = {}
        for node in graph.nodes:
            name_type[node.name] = node.type
        return name_type

    @staticmethod
    def get_support_quant_layer2type(graph):
        '''return supported layer to type map in graph'''
        quant_layers = {}
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node):
                quant_layers[node.name] = node.type
        return quant_layers

    @staticmethod
    def get_support_quant_layers(graph):
        '''return supported quant layers in graph'''
        quant_layers = []
        for node in graph.nodes:
            if GraphChecker.check_quantize_type(node):
                quant_layers.append(node.name)
        return quant_layers

    @staticmethod
    def get_support_int16_quantizable_layers(graph):
        '''return supported int16 quantize layers in model'''
        layers = []
        for node in graph.nodes:
            if GraphChecker.check_graph_int16_quantize_type(node):
                layers.append(node.name)
        return layers

    @staticmethod
    def get_skip_quant_layers(graph):
        '''return need to skip quant layers in graph'''
        skip_quant_layers = []
        for node in graph.nodes:
            if node.has_attr("is_update") and node.get_attr('is_update'):
                if not GraphChecker.check_quantize_type(node):
                    skip_quant_layers.append(node.name)
        return skip_quant_layers

    @staticmethod
    def get_support_convert_layers(graph):
        '''return supported QAT conversion layers in graph'''
        quantable_layers = []
        for node in graph.nodes:
            if GraphChecker.check_convert_qat_quantize_type(node):
                quantable_layers.append(node.name)
        return quantable_layers

    @staticmethod
    def get_nuq_quant_layers(graph):
        '''get nuq quant layers'''
        layers = []
        for node in graph.nodes:
            if GraphChecker.check_nuq_quantize_type(node):
                layers.append(node.name)
        return layers

    @staticmethod
    def check_nuq_steps(graph, layer_name, steps):
        '''check if nuq steps is bigger than weight length'''
        node = graph.get_node_by_name(layer_name)
        weight_node = QuantOpInfo.get_weight_node(node)
        weight_tensor = QuantOpInfo.get_node_tensor(weight_node)
        weight_length = TensorProtoHelper(weight_tensor, model_path=graph.model_path).get_data().size

        if weight_length < steps:
            return False
        return True

    @staticmethod
    def check_op_matching(graph, fused_op_list):
        """
        Function: Check whether the ops in json the ops in the original graph
        Inputs:
            graph: Graph, to be quantized
            fused_op_list: list, the ops parsed from the json file
        """
        # check whether the ops in json the ops in the original graph
        original_graph_ids = graph.node_ids
        for json_op_name in fused_op_list:
            is_quant_op = False
            for quant_suffix in QUANT_LAYER_SUFFIX:
                if quant_suffix in json_op_name:
                    is_quant_op = True
            if is_quant_op:
                continue
            if json_op_name not in original_graph_ids:
                LOGGER.logd(
                    "Op '{}' in the given mapping_file does not exist in the original graph. "\
                    "The mapping_file may not match the original graph, "\
                    "please check!".format(json_op_name))

    @staticmethod
    def get_act_symmetric_limit_types():
        """get type only support activation symmetric"""
        types = []
        return types

    @staticmethod
    def get_act_symmetric_limit_layers(graph):
        """get layer only support activation symmetric"""
        layers = []
        for node in graph.nodes:
            if node.type in ['Conv'] and check_kernel_shape(node, [3]):
                layers.append(node.name)
            elif node.type == 'MatMul' and _check_matmul_two_input(node):
                layers.append(node.name)
        return layers

    @staticmethod
    def get_weights_corresponding_layers(graph, quant_config, quantizable_layers):
        """
        Function: get all weights and corresponding quant layers in graph
        Inputs:
            graph: Graph, to be quantized
            quant_config: a dict, quant config
            quantizable_layers: a list, containing name of layers in
                quant_config
        Returns:
            weights_corresponding_layers: a dict, key: weight_tensor_name, value: list of layer_name
        """
        weights_corresponding_layers = dict()
        for layer_name in list(quant_config.keys()):
            if layer_name not in quantizable_layers:
                continue
            node = graph.get_node_by_name(layer_name)
            if node.type == 'AveragePool':
                continue
            weight_tensor_name = QuantOpInfo.get_weight_node(node).name
            if weights_corresponding_layers.get(weight_tensor_name) is None:
                weights_corresponding_layers[weight_tensor_name] = [layer_name]
            else:
                weights_corresponding_layers.get(weight_tensor_name).append(layer_name)

        return weights_corresponding_layers

    @staticmethod
    def get_support_dmq_balancer_types():
        """get type only support activation symmetric"""
        types = QUANTIZABLE_TYPES
        types.remove('AveragePool')
        return types

    @staticmethod
    def get_support_dmq_balancer_layers(graph):
        """get layer only support activation symmetric"""
        layers = []
        for node in graph.nodes:
            if node.type == 'MatMul' and _check_matmul_two_input(node):
                continue
            if GraphChecker.check_quantize_type(node) and node.type not in ['AveragePool', 'LSTM', 'GRU']:
                layers.append(node.name)
        quant_layers = GraphQuerier.get_support_quant_layers(graph)
        weights_corresponding_layers = GraphQuerier.get_weights_corresponding_layers(
            graph, dict.fromkeys(quant_layers, []), quant_layers)
        shared_weight_layer_name = []
        for shared_weight_layers in weights_corresponding_layers.values():
            if len(shared_weight_layers) == 1:
                continue
            for layer in shared_weight_layers:
                shared_weight_layer_name.append(layer)
        return [layer for layer in layers if layer not in shared_weight_layer_name]

    @staticmethod
    def get_support_winograd_quant_layers(graph):
        """get layers support int6 int7 quant"""
        layers = []
        for node in graph.nodes:
            if node.type in ['Conv'] and check_kernel_shape(node, [2]):
                layers.append(node.name)
        return layers

    @staticmethod
    def get_support_winograd_layer_types():
        """get layer types support int6 int7 quant"""
        return ['Conv']

class GraphChecker():
    """Check the graph."""
    @staticmethod
    def check_quantize_type(node):
        """ check if node in graph can be quantized or not."""
        # check type
        if node.type not in QUANTIZABLE_TYPES:
            return False

        if node.type in ['Conv']:
            # must be 1D, 2D or 3D
            if not check_kernel_shape(node, [2, 3]):
                return False

        if node.type == 'ConvTranspose':
            if not check_kernel_shape(node, [2]):
                return False

        if node.type == 'AveragePool':
            # must be 2D
            if not check_kernel_shape(node, [2]):
                return False
        if not GraphChecker.check_special_limit(node):
            return False

        if node.type in ['LSTM']:
            if not check_lstm_limit(node):
                return False
        if node.type == 'GRU':
            if not check_gru_limit(node):
                return False

        return True

    @staticmethod
    def check_graph_int16_quantize_type(node):
        """ check if node in graph can be int16 quantized or not."""
        # check type
        if node.type not in INT16_QUANTIZABLE_TYPES:
            return False

        if node.type in ['Conv']:
            # only conv2d support int16
            if not check_kernel_shape(node, [2]):
                return False
        elif node.type in ['ConvTranspose']:
            # convtranspose2d support int16
            if not check_kernel_shape(node, [2]):
                return False

        return GraphChecker.check_special_limit(node)

    @staticmethod
    def check_convert_qat_quantize_type(node):
        """ check if node in graph support convert qat or not."""
        # check type
        if node.type not in CONVERT_QAT_QUANTIZABLE_TYPES:
            return False
        if node.type in ['Conv', 'ConvTranspose']:
            # conv1D conv2D conv3D
            if not check_kernel_shape(node, [2, 3]):
                return False
            if node.type == 'ConvTranspose':
                # dilation is 1 for convtranspose2d
                if get_kernel_shape(node) == 2 and \
                    not _check_dilation(node, ['1', [1, 1]]):
                    return False
        if node.type == 'LSTM':
            if not check_lstm_limit(node, check_weight=False):
                return False
        if node.type == 'GRU':
            if not check_gru_limit(node, check_weight=False):
                return False
        return GraphChecker.check_special_limit(node, is_constant=False)

    @staticmethod
    def check_nuq_quantize_type(node):
        """ check if node can be non uniform quantized or not."""
        # check type
        if node.type not in CAPACITY.get_value('NUQ_QUANTIZABLE_TYPES'):
            return False

        if node.type in ['Conv', 'ConvTranspose']:
            # must be conv2D conv3D
            if not check_kernel_shape(node, [2, 3]):
                return False
            # dilation must be 1
            if not _check_dilation(node, ['1', [1, 1], [1, 1, 1]]):
                return False
            # group must be 1
            if not _check_group(node, ['1', 1]):
                return False

        return GraphChecker.check_special_limit(node)

    @staticmethod
    def check_weight_constant_input(node):
        """check whether node input is in const"""
        if not MATMUL_TWO_INPUT and 'MatMul' not in HAS_WEIGHT_TYPE:
            HAS_WEIGHT_TYPE.append('MatMul')

        if node.type not in HAS_WEIGHT_TYPE:
            return True

        weights_node = QuantOpInfo.get_weight_node(node)
        if weights_node.type not in CONSTANT_NODE_TYPE:
            LOGGER.logd('Cannot support quantize node "{}" without '
                        'constant weights.'.format(node.name))
            return False
        bias_node = QuantOpInfo.get_bias_node(node)
        if bias_node is not None and \
                bias_node.type not in CONSTANT_NODE_TYPE:
            LOGGER.logd('Cannot support quantize node "{}" without'
                        'constant bias.'.format(node.name))
            return False

        if node.type in RNN_LAYER_TYPE:
            recurrence_weights_node = QuantOpInfo.get_recurrence_weight_node(node)
            if recurrence_weights_node.type not in CONSTANT_NODE_TYPE:
                LOGGER.logd('Cannot support quantize node "{}" without '
                            'constant recurrence weight.'.format(node.name))
                return False
        return True

    @staticmethod
    def check_special_limit(node, is_constant=True):
        """ Check if the node in graph satisfy special limits ro be quantized,
            limits include:
                1. Gemm's transA must be false; alpha and beta must be 1
                2. weight must be constant
                3. check MatMul weight shape
        """
        # Check Gemm's attribute
        if node.type == 'Gemm':
            if not _check_gemm(node):
                return False

        if not is_constant:
            return True

        if not GraphChecker.check_weight_constant_input(node):
            return False

        if node.type == 'MatMul':
            if not _check_matmul(node):
                return False

        return True

    @staticmethod
    def check_quant_behaviours(graph):
        """
        Function: Check whether there're quant behaviours in the graph.
            If there're layers defined by AMCT, raise error.
        Inputs:
            graph: Graph, the graph to be checked.
        Return: None
        """
        tools_defined_layers = []
        # find all layers whose type is in AMCT_OPERATIONS in onnx graph
        for node in graph.nodes:
            if node.type in AMCT_OPERATIONS:
                tools_defined_layers.append(node.name)

        if tools_defined_layers:
            raise RuntimeError("The model cannot be quantized for following "\
                "quant layers are in the model %s" % (tools_defined_layers))

    @staticmethod
    def check_convert_behaviours(graph):
        """
        Function: Check whether there're fakequant node in the graph.
        Inputs:
            graph: Graph, the graph to be checked.
        Return: None
        """
        is_satisfied = False
        for node in graph.nodes:
            if node.type in ['QuantizeLinear', 'DequantizeLinear']:
                is_satisfied = True
                break
        if not is_satisfied:
            raise RuntimeError("The model cannot be converted for not finding "\
                "any QuantizeLinear or DequantizeLinear layers in the model")

    @staticmethod
    def check_tensor_quant(graph, quant_tensors):
        """
        Function: Check whether tensor exists in the graph and if
        tensor.op's type is quantizable
        Inputs:
        graph: tf.compat.v1.Graph
        quant_tensors: a list of quant-tensors.
        Raise:
        TypeError: tensor.op's type in quantizable types
        RuntimeError: tensor not found in graph
        """
        for tensor_dict in quant_tensors:
            op_name = tensor_dict.get('layer_name')
            tensor_idx = tensor_dict.get('input_index')
            try:
                op = graph.get_node_by_name(op_name)
            except (ValueError, SyntaxError, KeyError) as e:
                raise RuntimeError(
                    "Operation %s is not found in the given Graph." %
                    (op_name)) from e
            if op.type not in TENSOR_QUANTIZABLE_TYPES:
                raise TypeError(
                    "Type %s is not supported for tensor quantization." % (op.type))
            if tensor_idx >= len(op.input_anchors):
                raise IndexError(
                    "Input index %d is out of range for the operation %s" % (tensor_idx, op_name))


def get_kernel_shape(node):
    """ get node kernel shape from attribute or weight """
    attrs_helper = AttributeProtoHelper(node.proto)
    if attrs_helper.has_attr('kernel_shape'):
        filter_shape = attrs_helper.get_attr_value('kernel_shape')
    else:
        weight_tensor = QuantOpInfo.get_weight_tensor(node)
        filter_shape = weight_tensor.dims
        filter_shape = filter_shape[2:]
    return filter_shape


def check_kernel_shape(node, kernel_shape_range):
    """ Check whether the node's kernel_shape satisfy kernel_shape_range"""
    filter_shape = get_kernel_shape(node)
    if len(filter_shape) not in kernel_shape_range:
        LOGGER.logd("Layer %s's kernel_shape is %s." %
                    (node.name, filter_shape),
                    module_name=MODULE_NAME)
        return False

    return True


def _check_dilation(node, dilation_range):
    """ Check whether the node's dilation satisfy dilation_range"""
    attrs_helper = AttributeProtoHelper(node.proto)
    if not attrs_helper.has_attr('dilations'):
        dilation = '1'
    else:
        dilation = attrs_helper.get_attr_value('dilations')

    if dilation not in dilation_range:
        LOGGER.logd("Layer %s's dilation is %s, range is %s." % (node.name, dilation, dilation_range),
                    MODULE_NAME)
        return False

    return True


def _check_group(node, group_range):
    """ Check whether the Conv node's group satisfy group_range"""
    attrs_helper = AttributeProtoHelper(node.proto)
    if not attrs_helper.has_attr('group'):
        group = '1'
    else:
        group = attrs_helper.get_attr_value('group')

    if group not in group_range:
        LOGGER.logd("Layer %s's group is %s." % (node.name, group),
                    MODULE_NAME)
        return False

    return True


def _check_gemm(node):
    """ Check whether Gemm can be quantized """
    attrs_helper = AttributeProtoHelper(node.proto)
    if attrs_helper.has_attr('transA') and \
            attrs_helper.get_attr_value('transA') == 1:
        LOGGER.logw('Cannot support quantize "Gemm" layer "{}" with '
                    'transA:True.'.format(node.name), MODULE_NAME)
        return False
    if attrs_helper.has_attr('alpha'):
        alpha = attrs_helper.get_attr_value('alpha')
        if alpha != 1.0:
            LOGGER.logw('Cannot support quantize "Gemm" layer "{}" with '
                        'alpha:{}.'.format(node.name, alpha), MODULE_NAME)
            return False
    if attrs_helper.has_attr('beta'):
        beta = attrs_helper.get_attr_value('beta')
        if beta != 1.0:
            LOGGER.logw('Cannot support quantize "Gemm" layer "{}" with '
                        'beta:{}.'.format(node.name, beta), MODULE_NAME)
            return False
    return True


def _check_matmul(node):
    """ Check whether MatMul can be quantized """
    weights_node = QuantOpInfo.get_weight_node(node)
    if weights_node.type not in CONSTANT_NODE_TYPE:
        node.set_attr(ATTR_NODE_TWO_INPUTS, True)
        return True
    weight_tensor = QuantOpInfo.get_node_tensor(weights_node)
    shape = weight_tensor.dims
    if len(shape) not in MATMUL_WEIGHT_DIMS:
        LOGGER.logd('Cannot support quantize "MatMul" layer "{}" for weight '
                    'dim({}) is not in {}.'.format(node.name, len(shape), MATMUL_WEIGHT_DIMS), MODULE_NAME)
        return False

    return True


def _check_matmul_two_input(node):
    """ Check whether MatMul is two input tensor"""
    weights_node = QuantOpInfo.get_weight_node(node)
    if weights_node.type not in CONSTANT_NODE_TYPE:
        return True
    return False


def check_gru_limit(node, check_weight=True):
    """ Check whether GRU op is quantizable"""
    if check_weight and not _check_rnn_weight_limit(node):
        return False
    if not _check_gru_input_limit(node):
        return False
    if not _check_attrs_limit(node, GRU_ATTRS_LIMIT_MAP):
        return False
    if not _check_output_num_limit(node, GRU_OUTPUT_NUMS):
        return False
    attrs_helper = AttributeProtoHelper(node.proto)
    linear_before_reset = 0
    if attrs_helper.has_attr('linear_before_reset'):
        linear_before_reset = attrs_helper.get_attr_value('linear_before_reset')
    if linear_before_reset == 0:
        return False
    return True


def check_lstm_limit(node, check_weight=True):
    """ Check whether LSTM is quantizable. """
    if not _check_lstm_input_limit(node):
        return False
    if not _check_output_num_limit(node, LSTM_OUTPUT_NUMS):
        return False
    if check_weight and not _check_rnn_weight_limit(node):
        return False
    if not _check_attrs_limit(node, LSTM_ATTRS_LIMIT_MAP):
        return False
    return True


def _check_lstm_input_limit(node):
    """ Check whether LSTM input meet quantization limit """
    node_input_anchors = node.input_anchors
    if len(node_input_anchors) < LSTM_C_INDEX + 1 or \
        node_input_anchors[LSTM_C_INDEX].get_peer_output_anchor() is None:
        LOGGER.logd('Node {} cannot be quantized '
                    'for it has no initial_c input'.format(node.name))
        return False

    initial_c = node_input_anchors[LSTM_C_INDEX].get_peer_output_anchor().node
    if not _check_node_linked_to_outside_input(initial_c):
        LOGGER.logd('Node {} cannot be quantized '
                    'for its initial_c is not linked to graph_input'.format(node.name))
        return False

    if node_input_anchors[RNN_H_INDEX].get_peer_output_anchor() is None:
        LOGGER.logd('Node {} cannot be quantized '
                    'for it has no initial_h input'.format(node.name))
        return False

    initial_h = node_input_anchors[RNN_H_INDEX].get_peer_output_anchor().node
    if not _check_node_linked_to_outside_input(initial_h):
        LOGGER.logd('Node {} cannot be quantized '
                    'for its initial_h is not linked to graph_input'.format(node.name))
        return False

    if node_input_anchors[RNN_SEQ_LENS_INDEX].get_peer_output_anchor() is not None:
        LOGGER.logd('Node {} cannot be quantized '
                    'for it has sequence_lens input'.format(node.name))
        return False
    if len(node_input_anchors) > LSTM_P_INDEX and \
        node_input_anchors[LSTM_P_INDEX].get_peer_output_anchor() is not None:
        LOGGER.logd('Node {} cannot be quantized for it has P input'.format(node.name))
        return False
    return True


def _check_output_num_limit(node, output_num):
    """ Check whether LSTM output meet quantization limit """
    node_output_anchors = node.output_anchors
    if len(node_output_anchors) < output_num:
        LOGGER.logd('Node {} cannot be quantized for its output is less than {}.'.format(node.name, output_num))
        return False
    for idx, output_anchor in enumerate(node_output_anchors):
        if output_anchor.get_peer_input_anchor is None:
            LOGGER.logd('Node {} cannot be quantized for its {} output is None'.format(node.name, idx))
            return False
    return True


def _check_rnn_weight_limit(node):
    """ Check whether RNN weight meet quantization limit """
    weights_node = QuantOpInfo.get_weight_node(node)
    weight_tensor = QuantOpInfo.get_node_tensor(weights_node)
    weight_shape = weight_tensor.dims
    if weight_shape[0] != 1:
        LOGGER.logd('Node {} cannot be quantized '
                    'for its num_directions is not equal to 1'.format(node.name))
        return False

    recurrence_weights_node = QuantOpInfo.get_recurrence_weight_node(node)
    recurrence_weight_tensor = QuantOpInfo.get_node_tensor(recurrence_weights_node)
    recurrence_weight_shape = recurrence_weight_tensor.dims
    if recurrence_weight_shape[0] != 1:
        LOGGER.logd('Node {} cannot be quantized '
                    'for its num_directions is not equal to 1'.format(node.name))
        return False
    return True


def _check_gru_input_limit(node):
    node_input_anchors = node.input_anchors
    if len(node_input_anchors) < RNN_H_INDEX + 1 or \
        node_input_anchors[RNN_H_INDEX].get_peer_output_anchor() is None:
        LOGGER.logd('Node {} cannot be quantized '
                    'for it has no initial_h input'.format(node.name))
        return False

    if node_input_anchors[RNN_SEQ_LENS_INDEX].get_peer_output_anchor() is not None:
        LOGGER.logd('Node {} cannot be quantized '
                    'for it has sequence_lens input'.format(node.name))
        return False

    initial_h = node_input_anchors[RNN_H_INDEX].get_peer_output_anchor().node
    if not _check_node_linked_to_outside_input(initial_h):
        LOGGER.logd('Node {} cannot be quantized '
                    'for its initial_h is not linked to graph_input'.format(node.name))
        return False
    return True


def _check_attrs_limit(node, attrs_limit_map):
    """ Check whether operator's attributes in quant limit on map"""
    attrs_helper = AttributeProtoHelper(node.proto)

    for attr_name, attr_limit in attrs_limit_map.items():
        if not attrs_helper.has_attr(attr_name):
            continue
        attr_value = attrs_helper.get_attr_value(attr_name)
        if attr_limit is not None:
            if isinstance(attr_value, bytes):
                attr_value = attr_value.decode('utf-8')
            if attr_value != attr_limit:
                LOGGER.logd("Node {}'s {} is {}, while limit is {}".format(
                    node.name, attr_name, attr_value, attr_limit), MODULE_NAME)
                return False
        else:
            if attr_value is not None:
                LOGGER.logd("Node {} can not be quantized for "
                            "its {} is set.".format(node.name, attr_name))
                return False
    return True


def _check_node_linked_to_outside_input(node):
    """ Check whether node is linked to graph input directly or indirectly"""
    if node.type == 'graph_input':
        return True
    flag = False
    for input_anchor in node.input_anchors:
        input_node = input_anchor.get_peer_output_anchor().node
        if _check_node_linked_to_outside_input(input_node):
            flag = True
            break
    return flag


def _check_skip_pad_conv(quant_node, producer_node):
    """
    Function: check whether need skip pad node that before quant node
    Parameter: quant_node: node to be quant
               producer_node: node before quant_node
    Return: True: need skip pad node that before quant node
            False: no need skip pad node that before quant node
    """
    # conv2d
    if not check_kernel_shape(quant_node, [2]):
        return False

    pad_utils = PadUtils(producer_node)
    pad_pads = pad_utils.get_pads()
    # onnx::conv's attr pads is [H_top,W_left,H_bottom,W_right]
    quant_pads = np.zeros(4)
    attr_helper = AttributeProtoHelper(quant_node.proto)
    if attr_helper.has_attr("pads"):
        quant_pads = np.array(attr_helper.get_attr_value("pads"))
    quant_pads[0] += pad_pads[2] # H_top
    quant_pads[2] += pad_pads[6] # H_bottom
    quant_pads[1] += pad_pads[3] # W_left
    quant_pads[3] += pad_pads[7] # W_right
    # fused pads H/W axis should be in range [0,255]
    if np.any(quant_pads < 0) or np.any(quant_pads > 255):
        LOGGER.logd("({})+({}) cannot be quantized together, since fused pads({}) not "
            "in range [0,255].".format(producer_node.name, quant_node.name, quant_pads), MODULE_NAME)
        return False

    weight_tensor = QuantOpInfo.get_weight_tensor(quant_node)
    kernel_h = weight_tensor.dims[2]
    # fused pads H_top/H_bottom should less than kernel_h
    if quant_pads[0] >= kernel_h or quant_pads[2] >= kernel_h:
        LOGGER.logd("({})+({}) cannot be quantized together, since fused pads({}) in H axis "
            "not less than kernel_h({}).".format(
            producer_node.name, quant_node.name, quant_pads, kernel_h), MODULE_NAME)
        return False

    return True


def _check_skip_pad_avgpool(quant_node, producer_node):
    """
    Function: check whether need skip pad node that before quant node
    Parameter: quant_node: node to be quant
               producer_node: node before quant_node
    Return: True: need skip pad node that before quant node
            False: no need skip pad node that before quant node
    """
    # avgpool's all pads=0
    attrs_helper = AttributeProtoHelper(quant_node.proto)
    if attrs_helper.has_attr('pads'):
        quant_node_pads = np.array(attrs_helper.get_attr_value('pads'))
        if np.any(quant_node_pads != 0):
            LOGGER.logd("({})+({}) cannot be quantized together, since avgpool's "
                "pads({}) not all zero.".format(
                producer_node.name, quant_node.name, quant_node_pads), MODULE_NAME)
            return False

    # pad's pads in H/W axis should less than avgpool's kernel_shape in H/W
    pad_utils = PadUtils(producer_node)
    pad_pads = pad_utils.get_pads()
    kernel_shape = attrs_helper.get_attr_value('kernel_shape')
    if pad_pads[2] >= kernel_shape[0] or pad_pads[6] >= kernel_shape[0]:
        LOGGER.logd("({})+({}) cannot be quantized together, since pad's pads({}) "
            "in H axis not less than avgpool's kernel_shape({}).".format(
            producer_node.name, quant_node.name, pad_pads, kernel_shape), MODULE_NAME)
        return False
    if pad_pads[3] >= kernel_shape[1] or pad_pads[7] >= kernel_shape[1]:
        LOGGER.logd("({})+({}) cannot be quantized together, since pad's pads({}) "
            "in W axis not less than avgpool's kernel_shape({}).".format(
            producer_node.name, quant_node.name, pad_pads, kernel_shape), MODULE_NAME)
        return False

    return True


def check_skip_pad(quant_node, producer_node):
    """
    Function: check whether need skip pad node that before quant node
    Parameter: quant_node: node to be quant
               producer_node: node before quant_node
    Return: True: need skip pad node that before quant node
            False: no need skip pad node that before quant node
    """
    if producer_node.type != 'Pad':
        return False

    if quant_node.type not in ['AveragePool', 'Conv']:
        return False

    pad_consumers, _ = producer_node.get_consumers(0)
    if len(pad_consumers) > 1:
        LOGGER.logd("({})+({}) cannot be quantized together, since pad's consumer "
            "more than one.".format(producer_node.name, quant_node.name), MODULE_NAME)
        return False

    pad_utils = PadUtils(producer_node)
    if not pad_utils.check_pads():
        LOGGER.logd("({})+({}) cannot be quantized together, since get constant pad's pads "
            "failed.".format(producer_node.name, quant_node.name), MODULE_NAME)
        return False
    # pad's mode is constant and constant_value=0, constant_value's data_type is float
    constant_value = pad_utils.get_pad_value()
    if constant_value != 0:
        LOGGER.logd("({})+({}) cannot be quantized together, since pad's constant_value "
            "not zero.".format(producer_node.name, quant_node.name), MODULE_NAME)
        return False
    if isinstance(constant_value, np.ndarray):
        if constant_value.dtype != np.float32:
            LOGGER.logd("({})+({}) cannot be quantized together, since pad's constant_value "
                "data_type not float.".format(producer_node.name, quant_node.name), MODULE_NAME)
            return False
    elif not isinstance(constant_value, float):
        LOGGER.logd("({})+({}) cannot be quantized together, since pad's constant_value "
            "data_type not float.".format(producer_node.name, quant_node.name), MODULE_NAME)
        return False

    # pad's attr pads [N_begin,C_begin,H_top,W_left,N_end,C_end,H_bottom,W_right]
    # should be zero in N/C axis
    pad_pads = pad_utils.get_pads()
    flag = pad_pads[0] != 0 or pad_pads[1] != 0 or pad_pads[4] != 0 or pad_pads[5] != 0
    if flag:
        LOGGER.logd("({})+({}) cannot be quantized together, since pad's pads({}) not zero "
            "in N/C axis.".format(producer_node.name, quant_node.name, pad_pads), MODULE_NAME)
        return False

    # if auto_pad not in [b'NOTSET', b'VALID'], pads value is calculated from
    # input_shape and strides, cannot be checked
    attr_helper = AttributeProtoHelper(quant_node.proto)
    if attr_helper.has_attr("auto_pad"):
        auto_pad = attr_helper.get_attr_value("auto_pad")
        if auto_pad not in [b'NOTSET', b'VALID']:
            LOGGER.logd("({})+({}) cannot be quantized together, since auto_pad not "
                "NOTSET or VALID.".format(producer_node.name, quant_node.name), MODULE_NAME)
            return False

    if quant_node.type == 'Conv':
        if not _check_skip_pad_conv(quant_node, producer_node):
            return False
    elif quant_node.type == 'AveragePool':
        if not _check_skip_pad_avgpool(quant_node, producer_node):
            return False

    return True