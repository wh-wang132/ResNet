#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

class FuseConvScale, fuse CONV and Scale.

"""
from amct_onnx.common.algo.conv_scale_fuse_base import FuseConvScaleBase


def fuse_conv_scale(conv_weight, conv_bias, scale, beta):
    """fuse conv and scale"""
    return FuseConvScaleBase.fuse_conv_scale(conv_weight, conv_bias, scale, beta)
