#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

NUQ quantize algorithm
"""

from amct_onnx.lib.load_library import Load
from amct_onnx.common.algo.arq_algo_base import ArqAlgoBase
from amct_onnx.common.algo.nuq_algo_base import NuqAlgoBase

WEIGHTS_QUANT_ALGO = {}
WEIGHTS_QUANT_ALGO['arq_quantize'] = ArqAlgoBase(lib_loader=Load(),
                                                 enable_gpu=False)
WEIGHTS_QUANT_ALGO['nuq_quantize'] = NuqAlgoBase(lib_loader=Load(),
                                                 enable_gpu=False)
