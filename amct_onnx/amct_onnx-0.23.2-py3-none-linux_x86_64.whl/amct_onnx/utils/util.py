#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2024. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

onnx common functions

"""


def find_all_nodes_before(node, input_nodes, other_nodes):
    """
    Fuction: find all nodes of a sub graph which end with the node
    Parameters:
        node: the end node
        input_nodes: input of the sub graph, initial value is []
        other_nodes: all nodes except the input, initial value is []
    Return: None
    """
    if len(node.input_anchors) == 0:
        input_nodes.append(node)
        return

    other_nodes.append(node)
    for in_idx in range(len(node.input_anchors)):
        producer, _ = node.get_producer(in_idx)
        if producer not in input_nodes + other_nodes:
            find_all_nodes_before(producer, input_nodes, other_nodes)
