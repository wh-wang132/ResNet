#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

the auto calibration helper

"""

import os
import stat
from collections import OrderedDict
import numpy as np
from onnx import onnx_pb
from onnx.onnx_pb import TensorProto
import onnxruntime as ort
import amct_onnx as amct
import amct_onnx.optimizer as opt
from amct_onnx.configuration.check import check_skip_pad
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.configuration.configuration import GraphChecker
from amct_onnx.graph.graph import Graph
from amct_onnx.parser.parser import Parser
from amct_onnx.common.utils import files as files_util
from amct_onnx.common.utils.check_params import check_params
from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.save import save_onnx_model
from amct_onnx.utils.util import find_all_nodes_before
from amct_onnx.common.utils.vars_util import RNN_LAYER_TYPE
from amct_onnx.utils.save import convert_external_data_format

BIAS_INPUT_INDEX = 2
DEQSCALE_INPUT_INDEX = 2
INPUT_SIZE_THREE = 3
INPUT_SIZE_TWO = 2
INPUT_IDX_TWO = 2
INT_SIZE = 4
FLOAT_SIZE = 4
HALF_SIZE = 2
INPUT = 'input'
ROLLBACK_EXCLUDED_LAYER_TYPE = RNN_LAYER_TYPE


def pretty_print(cos_sim_record):
    """ formate the print info"""
    for key, value in cos_sim_record.items():
        LOGGER.logi('{} : {} '.format(
            key, value), 'AutoCalibrationHelper')


def run_model(input_file_list, model_file):
    """ run the model with the input data"""
    if ort.get_device() == 'GPU':
        ort_session = ort.InferenceSession(
            model_file, amct.AMCT_SO, providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
    else:
        ort_session = ort.InferenceSession(
            model_file, amct.AMCT_SO, providers=['CPUExecutionProvider'])

    ort_inputs = {}
    for idx, input in enumerate(ort_session.get_inputs()):
        ort_inputs[input.name] = parse_fm_to_np(input_file_list[idx])
    output = ort_session.run(None, ort_inputs)
    return output


def parse_fm_to_np(file_path):
    """ Parse the dump fm file into numpy array dataformat"""
    real_file_path = os.path.realpath(file_path)
    files_util.check_file_path(real_file_path, 'feature_map_dump_file')
    shape_len = int(np.fromfile(real_file_path, np.int32, 1))
    shape = np.fromfile(real_file_path, np.int32, shape_len + 1)[1:]
    data_count = np.prod(shape)
    offset_size = INT_SIZE * (shape_len + 1)
    file_size = os.stat(real_file_path).st_size
    if file_size - offset_size == FLOAT_SIZE * data_count:
        dump_data = np.fromfile(real_file_path, np.float32)
        feature_map_data = dump_data[shape_len + 1:]
        return feature_map_data.reshape(shape)
    elif file_size - offset_size == HALF_SIZE * data_count:
        dump_data = np.fromfile(real_file_path, np.float16)
        feature_map_data = dump_data[(shape_len + 1) * 2:]
        return feature_map_data.reshape(shape)
    else:
        raise RuntimeError("File's size not match fp16 or fp32.")


class AutoCalibrationHelper:
    """ The helper class for auto calibration"""
    def __init__(self,
                 fused_model_file,
                 fq_model_file,
                 quant_layers,
                 record_file,
                 amct_log_dir,
                 sensitivity):
        """ init func of class AutoCalibrationHelper"""
        self.fused_model_file = fused_model_file
        self.fq_model_file = fq_model_file

        self.quant_layers = quant_layers
        self.record_file = record_file
        self.amct_log_dir = amct_log_dir
        self.history_record = OrderedDict()
        self.cosine_similarity_records = OrderedDict()
        self.single_layer_model_file = os.path.join(
            os.path.realpath(amct_log_dir), 'single_layer.onnx')
        self.fq_single_layer_model_file = os.path.join(
            os.path.realpath(amct_log_dir), 'fake_quant_single_layer.onnx')
        self.dump_files_list = []
        self.sensitivity = sensitivity
        self._init_graph()

    @staticmethod
    def copy_node_func(net, node):
        """ copy node func"""
        if node.type == 'initializer':
            copy_node = net.graph.initializer.add()
            copy_node.CopyFrom(node.dump_proto())
        elif node.type == 'Constant':
            copy_node = net.graph.node.add()
            copy_node.CopyFrom(node.dump_proto())
        else:
            raise RuntimeError(
                'node type {} is not initializer or constant node.'.format(
                    node.type))
        return net

    @staticmethod
    def copy_pads(net, node):
        """ copy pad node's pads """
        input_nodes = list()
        other_nodes = list()
        find_all_nodes_before(node, input_nodes, other_nodes)
        for each_node in input_nodes + other_nodes:
            if each_node.type == 'initializer':
                copy_node = net.graph.initializer.add()
                copy_node.CopyFrom(each_node.dump_proto())
            else:
                copy_node = net.graph.node.add()
                copy_node.CopyFrom(each_node.dump_proto())
        return net

    @staticmethod
    def copy_pad_node_func(net, node):
        """ copy the pad node"""
        input_size = len(node.input_anchors)
        if input_size >= INPUT_SIZE_TWO:
            pads_node = \
                node.get_input_anchor(1).get_peer_output_anchor().node
            net = AutoCalibrationHelper.copy_pads(net, pads_node)
        if input_size == INPUT_SIZE_THREE:
            constant_value_node = \
                node.get_input_anchor(INPUT_IDX_TWO).get_peer_output_anchor().node
            copy_node = net.graph.node.add()
            copy_node.CopyFrom(constant_value_node.dump_proto())
        return net

    @staticmethod
    def generate_new_net(org_net):
        """ generate new onnx net"""
        net = onnx_pb.ModelProto()
        opset_import = net.opset_import.add()
        opset_import.CopyFrom(org_net.opset_import[0])
        net.producer_name = org_net.producer_name
        net.producer_version = org_net.producer_version
        net.ir_version = org_net.ir_version
        return net

    @staticmethod
    def add_input_layer(input_array, net, input_name):
        """ add the input layer to the onnx net"""
        graph = net.graph
        input_value_info = graph.input.add()
        input_value_info.name = input_name
        if input_array.dtype == np.float32:
            input_value_info.type.tensor_type.elem_type = TensorProto.DataType.FLOAT
        elif input_array.dtype == np.float16:
            input_value_info.type.tensor_type.elem_type = TensorProto.DataType.FLOAT16
        for dim_info in input_array.shape:
            input_shape_dim = input_value_info.type.tensor_type.shape.dim.add()
            if isinstance(dim_info, str):
                input_shape_dim.dim_param = dim_info
            elif isinstance(dim_info, int):
                input_shape_dim.dim_value = dim_info
            else:
                raise RuntimeError("  error: only support str and int")
        return net

    @staticmethod
    def add_output_layer(net):
        """ add the input layer to the onnx net"""
        output_value_info = net.graph.output.add()
        output_value_info.name = 'output'
        output_value_info.type.tensor_type.elem_type = net.graph.input[0].type.tensor_type.elem_type
        return net

    @staticmethod
    def save_onnx_file(dump_model, file_path, graph, model_type=None):
        """ Save the net to onnx file"""
        #save in .onnx
        files_util.create_file_path(file_path)
        convert_external_data_format(dump_model, graph, file_path, model_type)
        with open(file_path, 'wb') as fid:
            fid.write(dump_model.SerializeToString())
        # set permission 640
        os.chmod(file_path, stat.S_IRUSR + stat.S_IWUSR + stat.S_IRGRP)
        LOGGER.logi(
            "The model_file is saved in %s" % (file_path),
            module_name='AutoCalibrationHelper')


    def find_fm_file_path(self, layer_name):
        """ find the dumped feature map blob binary files in amct_log_dir"""
        fm_file_list = [[]]
        layer_name_prefix = '{}_{}'.format(
            layer_name.replace('/', '_'), 'act_calibration_layer')
        log_dir = os.path.realpath(self.amct_log_dir)
        file_list = sorted(os.listdir(log_dir))
        for file_name in file_list:
            if not file_name.startswith(layer_name_prefix):
                continue
            dump_info = file_name.split('act_calibration_layer_dump')[1].replace('.bin', '')
            batch_index = int(dump_info.split('_')[1])
            if batch_index <= len(fm_file_list):
                fm_file_list[batch_index - 1].append(os.path.join(log_dir, file_name))
            else:
                fm_file_list.append([os.path.join(log_dir, file_name)])
        return fm_file_list

    def calc_ranking_info(self):
        """ calculate the cosine  similarity of single layer model and
            fake quant single layer model
        """
        real_amct_log_dir = os.path.realpath(self.amct_log_dir)
        if not os.path.isdir(real_amct_log_dir):
            raise RuntimeError(
                'amct_log dir {} does not exists!'.format(real_amct_log_dir))

        for layer_name in self.quant_layers:
            node = self.original_graph.get_node_by_name(layer_name)
            if node.type in ROLLBACK_EXCLUDED_LAYER_TYPE:
                LOGGER.logd('Node {} type {} is excluded in roll back.'.format(
                    layer_name, node.type))
                continue
            fm_file_list = self.find_fm_file_path(layer_name)
            if len(fm_file_list[0]) == 0:
                raise RuntimeError(
                    "Can not find dump file for layer {}".format(layer_name))
            # generate single layer model
            cos_sim_list = list()
            for fm_file in fm_file_list:
                single_layer_net = self.generate_single_model(
                    layer_name, fm_file)
                fake_single_layer_net = self.generate_fake_single_model(
                    layer_name, fm_file)
                # calc sim for each batch
                original_output = run_model(
                    fm_file, single_layer_net)
                fake_quant_output = run_model(
                    fm_file, fake_single_layer_net)
                cos_sim = self.sensitivity.compare(
                    original_output[0].flatten(),
                    fake_quant_output[0].flatten())
                cos_sim_list.append(cos_sim)

            self.cosine_similarity_records[layer_name] = np.mean(cos_sim_list)
            LOGGER.logi(
                "******** sensitivity of layer {} is {} ********".format(
                    layer_name, cos_sim))
        LOGGER.logi(
            '******** sensitivity_records ******** ', 'AutoCalibrationHelper')
        pretty_print(self.cosine_similarity_records)

        return self.cosine_similarity_records

    def generate_single_model(self, layer_name, input_file_list):
        """ generate the single layer prototxt file """
        graph = self.original_graph.deep_copy()
        net = self.generate_new_net(graph.net)
        object_node = None
        for node in graph.nodes:
            if node.name == layer_name:
                object_node = node
        if object_node is None:
            raise RuntimeError(
                'Can not find the node {} in graph.'.format(layer_name))
        # when AveragePool support quantization, net is
        # input -> pad -> AveragePool -> output
        # when conv/gemm:  input -> pad -> conv/gemm -> output
        obj_producer, _ = object_node.get_producer(0)
        # skip pad means single model need include pad
        include_pad = check_skip_pad(object_node, obj_producer)
        if include_pad:
            np_feature_map = parse_fm_to_np(input_file_list[0])
            net = self.add_input_layer(np_feature_map, net, INPUT)
            copy_head_node = net.graph.node.add()
            copy_head_node.CopyFrom(obj_producer.dump_proto())
            copy_head_node.input[0] = INPUT

            net = self.copy_pad_node_func(net, obj_producer)
            copy_tail_node = net.graph.node.add()
            copy_tail_node.CopyFrom(object_node.dump_proto())
            copy_tail_node.output[0] = 'output'
        else:
            copy_node = net.graph.node.add()
            copy_node.CopyFrom(object_node.dump_proto())
            for idx, item in enumerate(input_file_list):
                np_feature_map = parse_fm_to_np(item)
                net = self.add_input_layer(np_feature_map, net, INPUT + str(idx))
                copy_node.input[idx] = INPUT + str(idx)
            copy_node.output[0] = 'output'
        # weight node can be initializer or const
        if len(object_node.input_anchors) > 1:
            weight_node = \
                object_node.get_input_anchor(1).get_peer_output_anchor().node
            if object_node.type == 'MatMul' and weight_node.type not in ['Constant', 'initializer']:
                pass
            else:
                net = self.copy_node_func(net, weight_node)
        if len(object_node.input_anchors) == INPUT_SIZE_THREE:
            bias_node = \
                object_node.get_input_anchor(
                    BIAS_INPUT_INDEX).get_peer_output_anchor().node
            net = self.copy_node_func(net, bias_node)

        net = self.add_output_layer(net)
        AutoCalibrationHelper.save_onnx_file(
            net, self.single_layer_model_file, graph)
        return self.single_layer_model_file

    def generate_fake_single_model(self, layer_name, input_file_list):
        """ generate the single fake quant layer prototxt file """
        graph = self.fq_graph.deep_copy()
        net = self.generate_new_net(graph.net)
        object_node = None
        dequant_node = None
        for node in graph.nodes:
            if node.name == layer_name:
                object_node = node
        if object_node is None:
            raise RuntimeError('Can not find the node {} in graph.'.format(layer_name))
        # add conv/gemm/AveragePool node
        copy_node = net.graph.node.add()
        copy_node.CopyFrom(object_node.dump_proto())
        # when AveragePool support quantization, net is
        # input-> quant -> pad -> AveragePool -> dequant -> output
        # when conv/gemm:  input-> quant -> conv/gemm -> dequant -> output
        include_pad = False
        obj_producer, _ = object_node.get_producer(0)
        # skip pad means single model need include pad
        include_pad = check_skip_pad(object_node, obj_producer)
        if include_pad:
            np_feature_map = parse_fm_to_np(input_file_list[0])
            net = self.add_input_layer(np_feature_map, net, INPUT)
            pad_node = obj_producer
            quant_node = pad_node.get_input_anchor(0).get_peer_output_anchor().node
            copy_quant_node = net.graph.node.add()
            copy_quant_node.CopyFrom(quant_node.dump_proto())
            copy_quant_node.input[0] = INPUT
            copy_pad_node = net.graph.node.add()
            copy_pad_node.CopyFrom(pad_node.dump_proto())
            net = self.copy_pad_node_func(net, pad_node)
        elif object_node.type == 'MatMul' and object_node.get_producer(1)[0].type not in ['Constant', 'initializer']:
            input_file_list.sort()
            for idx, item in enumerate(input_file_list):
                np_feature_map = parse_fm_to_np(item)
                net = self.add_input_layer(np_feature_map, net, INPUT + str(idx))
            quant_node_0 = object_node.get_input_anchor(0).get_peer_output_anchor().node
            copy_quant_node_0 = net.graph.node.add()
            copy_quant_node_0.CopyFrom(quant_node_0.dump_proto())
            copy_quant_node_0.name = copy_quant_node_0.name + '0'
            copy_quant_node_0.input[0] = 'input0'
            copy_quant_node_0.output[0] = 'quant.output0'
            quant_node_1 = object_node.get_input_anchor(1).get_peer_output_anchor().node
            copy_quant_node_1 = net.graph.node.add()
            copy_quant_node_1.CopyFrom(quant_node_1.dump_proto())
            copy_quant_node_1.name = copy_quant_node_0.name + '1'
            copy_quant_node_1.input[0] = 'input1'
            copy_quant_node_1.output[0] = 'quant.output1'
            copy_node.input[0] = 'quant.output0'
            copy_node.input[1] = 'quant.output1'
        else:
            np_feature_map = parse_fm_to_np(input_file_list[0])
            net = self.add_input_layer(np_feature_map, net, INPUT)
            quant_node = object_node.get_input_anchor(0).get_peer_output_anchor().node
            # add quant node
            copy_quant_node = net.graph.node.add()
            copy_quant_node.CopyFrom(quant_node.dump_proto())
            copy_quant_node.input[0] = INPUT

        peer_input_anchors = object_node.get_output_anchor(
            0).get_peer_input_anchor()
        for peer_input_anchor in peer_input_anchors:
            if peer_input_anchor.node.type == 'AscendDequant':
                dequant_node = peer_input_anchor.node
        if dequant_node is None:
            raise RuntimeError(
                'Can not find the dequant of node {} in graph.'.format(layer_name))

        if len(object_node.input_anchors) > 1:
            weight_node = object_node.get_input_anchor(1).get_peer_output_anchor().node
            if object_node.type == 'MatMul' and weight_node.type not in ['Constant', 'initializer']:
                pass
            else:
                net = self.copy_node_func(net, weight_node)

        if len(object_node.input_anchors) == INPUT_SIZE_THREE:
            bias_node = object_node.get_input_anchor(
                BIAS_INPUT_INDEX).get_peer_output_anchor().node
            net = self.copy_node_func(net, bias_node)

        copy_dequant_node = net.graph.node.add()
        copy_dequant_node.CopyFrom(dequant_node.dump_proto())
        dequant_param_node = dequant_node.get_input_anchor(1).get_peer_output_anchor().node
        net = self.copy_node_func(net, dequant_param_node)

        copy_dequant_node.output[0] = 'output'
        # add output node
        net = self.add_output_layer(net)

        AutoCalibrationHelper.save_onnx_file(net, self.fq_single_layer_model_file, graph, 'Fakequant')
        return self.fq_single_layer_model_file

    def _init_graph(self):
        """ do some initialization work of parsing model into graph."""
        files_util.check_file_path(self.fused_model_file, 'fused_model_file')
        files_util.check_file_path(self.fq_model_file, 'fq_model_file')
        # parse the original model
        self.original_graph = Parser.parse_net_to_graph(self.fused_model_file)
        # parse the fake quant model
        self.fq_graph = Parser.parse_net_to_graph(self.fq_model_file)


@check_params(
    graph=Graph,
    fused_model_file=str)
def inner_fuse_model(graph, fused_model_file):
    """
    Function: Modify graph, do conv+bn+scale fusion, weights calibration,
              insert IFMR layer and DeQuantLayer to each to be quantized layer,
              and save fused graph to onnx model.
    Parameter: graph: graph structure parsed from user onnx model
               fused_model_file: fused onnx model file path
    Return: None
    """
    # fuse and export modified onnx
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.TransposeFoldPass())
    if Configuration().get_fusion_switch():
        optimizer.add_pass(opt.BnMulFusionPass())
        optimizer.add_pass(opt.BnAddFusionPass())
        optimizer.add_pass(opt.ConvBnFusionPass())
    optimizer.do_optimizer(graph)

    save_onnx_model(graph, fused_model_file, None)


@check_params(
    graph=Graph,
    config_file=str,
    modified_onnx_file=str,
    record_file=str)
def inner_quantize_model(graph,
                         config_file,
                         modified_onnx_file,
                         record_file,
                         temp_dir):
    """
    Function: Modify graph, do conv+bn+scale fusion, weights calibration,
              insert IFMR layer and DeQuantLayer to each to be quantized layer,
              and save modified graph to onnx model, dump ifmr feature map;
    Parameter: graph: graph structure parsed from user onnx model
               modified_onnx_file: modified onnx model's model file path
    Return: None
    """
    GraphChecker.check_quant_behaviours(graph)

    config_file = os.path.realpath(config_file)
    record_file = files_util.create_empty_file(record_file)
    Configuration().init(config_file, record_file, graph)

    # fuse and export modified onnx
    optimizer = opt.GraphOptimizer()
    optimizer.add_pass(opt.TransposeFoldPass())
    if Configuration().get_fusion_switch():
        optimizer.add_pass(opt.BnMulFusionPass())
        optimizer.add_pass(opt.BnAddFusionPass())
        optimizer.add_pass(opt.ConvBnFusionPass())
    optimizer.add_pass(opt.WeightsCalibrationPass())
    optimizer.add_pass(opt.InsertActCalibrationPass(True, temp_dir))
    optimizer.add_pass(opt.SetFusionInfoPass())
    optimizer.do_optimizer(graph)

    save_onnx_model(graph, modified_onnx_file, None)
