#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Common data definition module.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import numpy as np
import onnx

from amct_onnx.utils.log import LOGGER
from amct_onnx.utils.onnx_initializer_util import TensorProtoHelper
from amct_onnx.common.utils import files as files_util

__all__ = ['save_onnx_model', 'generate_onnx_file_name', 'split_dir_prefix']

# Limitation of model is 2GB
MAXIMUM_PROTOBUF = 2000000000


def convert_external_data_format(onnx_model, graph_proto, file_name, model_type):
    """
    Function: save external data in file.
    Inputs:
        onnx_model: onnx.onnx_ml_pb2.ModelProto, a model to convert.
        graph_proto: IR Graph
        file_name: a string, a file(.onnx) to save net's information.
        model_type: the model is deploy, fakequant or other model
    Returns: None
    """
    tensor_size = list()
    ori_tensor_external = list()
    # original model path
    model_path = graph_proto.model_path
    
    # Sort all tensors
    for index, initializer in enumerate(onnx_model.graph.initializer):
        tensor_size.append((index, initializer.ByteSize()))
        if initializer.data_location == 1:
            ori_tensor_external.append(index)

    tensor_size.sort(key=lambda x:x[1], reverse=True)

    # save external_data of input model in output path
    for index in ori_tensor_external:
        initializer = onnx_model.graph.initializer[index]  
        external_file = _gen_external_file_name(initializer, file_name, model_type)
        TensorProtoHelper(initializer, model_path).save_external_data(
            os.path.dirname(file_name), external_file)

    for index, _ in tensor_size:
        # check 2 GB limit
        if onnx_model.ByteSize() < MAXIMUM_PROTOBUF:
            break

        initializer = onnx_model.graph.initializer[index]
        external_file = _gen_external_file_name(initializer, file_name, model_type)
        TensorProtoHelper(initializer, model_path).save_external_data(
            os.path.dirname(file_name), external_file)


def _gen_external_file_name(initializer, file_name, model_type):
    """
    Function: generate external filename
    Inputs:
        initializer: TensorProto.
        file_name: a string, the model name.
        model_type: model is deploy, fakequant or other model
    Returns: a string, external filename
    """
    if model_type == 'Fakequant':
        external_file = initializer.name + '_fakequant.external'
    elif model_type == 'Deploy':
        external_file = initializer.name + '_deploy.external'
    else:
        external_file = initializer.name + '.external'
    return external_file


def save_onnx_model(graph_proto, file_name, model_type=None):
    """
    Function: save graph_proto in file.
    Inputs:
        graph_proto: IR Graph, the graph_proto to be saved.
        file_name: a string, a file(.onnx) to save net's information.
        model_type: deploy or fakequant or others
    Returns: None
    """
    file_realpath = os.path.realpath(file_name)
    # save to file
    files_util.create_file_path(file_realpath, check_exist=True)
    model_dump = graph_proto.dump_proto()
    model_dump.graph.ClearField('value_info')
    convert_external_data_format(model_dump, graph_proto, file_realpath, model_type)
    with open(file_realpath, 'wb') as fid:
        fid.write(model_dump.SerializeToString())
    # set file's permission 640
    os.chmod(file_realpath, files_util.FILE_MODE)

    LOGGER.logi("The model file is saved in %s" % (file_realpath),\
                'Utils')


def generate_onnx_file_name(save_dir, save_prefix, save_type):
    ''' Generate model's name. '''
    if save_type != 'Deploy':
        file_suffix = 'fake_quant_model.onnx'
    else:
        file_suffix = 'deploy_model.onnx'

    if save_prefix == '':
        ckpt_file = os.path.join(save_dir, file_suffix)
    else:
        ckpt_file = os.path.join(save_dir, '_'.join([save_prefix,
                                                     file_suffix]))

    return ckpt_file


def split_dir_prefix(save_path):
    ''' split save_path to save_dir and save_prefix'''
    if save_path == '':
        save_dir = os.path.realpath(save_path)
        save_prefix = ''
    elif save_path != '' and save_path[-1] == '/':
        save_dir = os.path.realpath(save_path)
        save_prefix = ''
    else:
        save_dir, save_prefix = os.path.split(os.path.realpath(save_path))
    files_util.is_valid_save_prefix(save_prefix)

    return save_dir, save_prefix
