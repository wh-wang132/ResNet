#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

log

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os

from amct_onnx.common.utils.log_base import LoggerBase
from amct_onnx.common.utils.log_base import LOG_FILE_DIR
from amct_onnx.common.utils.log_base import check_level

LOG_SET_ENV = 'AMCT_LOG_LEVEL'
LOG_FILE_SET_ENV = 'AMCT_LOG_FILE_LEVEL'

DEFAULT_LOG_FILE_DIR = os.path.join(os.getcwd(), LOG_FILE_DIR)
LOG_NAME = 'amct_onnx.log'


class Logger(LoggerBase):
    """
    Function：Record debug，info，warning，error level log
    API：logd, logi, logw, loge
    """
    def __init__(self, log_dir, log_name):
        """
        Function: Create logger, console handler and file handler
        Parameter: log_dir: directory of log
                   log_name: name of log
        Return:None
        """
        LoggerBase.__init__(self, log_dir, log_name)

        # Get loging level from env
        console_level_onnx = 'info'
        env_dist = os.environ
        if LOG_SET_ENV in env_dist:
            console_level_onnx = env_dist[LOG_SET_ENV]
            console_level_onnx = console_level_onnx.upper()
            check_level(console_level_onnx, LOG_SET_ENV)

        file_level_onnx = 'info'
        if LOG_FILE_SET_ENV in env_dist:
            file_level_onnx = env_dist[LOG_FILE_SET_ENV]
            file_level_onnx = file_level_onnx.upper()
            check_level(file_level_onnx, LOG_FILE_SET_ENV)

        self.set_debug_level(console_level_onnx, file_level_onnx)


LOGGER = Logger(DEFAULT_LOG_FILE_DIR, LOG_NAME)
