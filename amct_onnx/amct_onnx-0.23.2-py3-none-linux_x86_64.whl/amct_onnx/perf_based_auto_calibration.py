#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (C) 2019. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use
this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0

Auto quantize model by performance.

"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import shutil

from amct_onnx.common.utils.check_params import check_params
from amct_onnx.common.utils.files import is_valid_name
from amct_onnx.common.utils.files import check_files_exist
import amct_onnx.quantize_tool as quantize_tool
from amct_onnx.common.auto_calibration.perf_based_auto_calibration_base import \
    PerfBasedAutoCalibrationBase
from amct_onnx.common.performance_utils.performance_policer import BatchRollBackStrategy
from amct_onnx.common.performance_utils.performance_policer import PerfStrategyBase
import amct_onnx.optimizer as opt
from amct_onnx.parser.parser import Parser
from amct_onnx.optimizer.graph_optimizer import GraphOptimizer
from amct_onnx.configuration.check import GraphChecker
from amct_onnx.utils.log import LOGGER
from amct_onnx.configuration.configuration import Configuration
from amct_onnx.utils.save import generate_onnx_file_name
from amct_onnx.parser.parse_record_file import RecordFileParser


__all__ = ['perf_based_auto_calibration']
PB_FILE = 'pb_file'


class PerfBasedAutoCalibration(PerfBasedAutoCalibrationBase):
    """
    The subclass of 'PerfBasedAutoCalibrationBase' in Onnx.
    Args:
        model_files: a list as [original_model_path, quantized_model_path]
        sampler_config_file (str): a string of config file path.
        save_dir (str): a string of quantized model file path.
        strategy (Strategy): A instance inherited from 'Strategy' and all the
            methods are implemented.
    """
    def __init__(self, model_files, sampler_config_file, save_dir, strategy):
        PerfBasedAutoCalibrationBase.__init__(
            self, sampler_config_file, save_dir, strategy, 'Onnx')

        self.original_model_file = os.path.realpath(model_files[0])
        self.quantized_model_file = os.path.realpath(model_files[1])

        origin_graph = Parser.parse_net_to_graph(model_files[0])
        GraphChecker.check_quant_behaviours(origin_graph)

    def update_iteration_recorder(self):
        """Update iteration's recorder."""
        PerfBasedAutoCalibrationBase.update_iteration_recorder(self)
        self.iter_recorder.add_items(self.iter_num, PB_FILE, 'model_path',
                                     '.onnx')
        if self.iter_num == 0:
            shutil.copy(self.original_model_file,
                        self.iter_recorder.recorders[self.iter_num][PB_FILE])
            LOGGER.logi(
                'Move the original onnx model name from [{}] to [{}].'.format(
                    self.original_model_file,
                    self.iter_recorder.recorders[self.iter_num][PB_FILE]))

    def get_quant_model_info(self):
        """Get quantized model's information."""
        graph = Parser.parse_net_to_graph(self.quantized_model_file, skip_model_check=True)
        is_quantized = False
        optimizer = GraphOptimizer()
        optimizer.add_pass(opt.GetQuantInfoPass(quant_info=self.quant_info))
        optimizer.do_optimizer(graph)
        for key, value in self.quant_info.get_quant_config().items():
            if key in self.quant_info.get_main_layers() and \
                isinstance(value, dict):
                if value['quant_enable']:
                    is_quantized = True
                    break
        if not is_quantized:
            LOGGER.loge(
                'the model[{}] is not quantized!'.format(
                    self.quantized_model_file))
            raise RuntimeError(
                'the model[{}] is not quantized!'.format(
                    self.quantized_model_file))

    def roll_back_and_save_model(self):
        """
        Generate the roll-back fake quant model and evaluate the fake quant
        model.
        """
        # turn down the joint quant in auto calibration
        quant_layer_num = self.extract_record_file()
        # Generate quantitative model by the pb_model and record file
        if quant_layer_num > 0:
            graph = Parser.parse_net_to_graph(self.original_model_file)
            self.do_fusion_passes(graph)

            # parse record
            tmp_modified_model_path = os.path.join(
                self.iter_recorder.recorders[self.iter_num]['model_path'], "modified_model.onnx")
            record_parser = RecordFileParser(
                self.iter_recorder.recorders[self.iter_num]['record_file'], graph, tmp_modified_model_path)
            records, _ = record_parser.parse_wrap()
            model_name_without_suffix = self.iter_recorder.recorders[self.iter_num][PB_FILE][:-5]
            # generate deploy model
            quantize_tool.inner_save_model(
                graph,
                records,
                model_name_without_suffix)
            ori_name = '{}_deploy_model.onnx'.format(
                model_name_without_suffix)
            new_name = self.iter_recorder.recorders[self.iter_num][PB_FILE]
            shutil.move(ori_name, new_name)
            LOGGER.logi(
                'Change the quantized model name from [{}] to [{}].'.format(
                    ori_name, new_name))
        else:
            new_name = self.iter_recorder.recorders[self.iter_num][PB_FILE]
            shutil.copy(self.original_model_file, new_name)

    def do_fusion_passes(self, graph):
        """do fusion passes extracted from interface of "quantize_model" """
        tmp_record_path = os.path.join(
                self.iter_recorder.recorders[self.iter_num]['model_path'], "useless_record.txt")
        Configuration().init(
            self.iter_recorder.recorders[self.iter_num]['config_file'], tmp_record_path, graph)
        optimizer = opt.GraphOptimizer()
        optimizer.add_pass(opt.TransposeFoldPass())
        if Configuration().get_fusion_switch():
            optimizer.add_pass(opt.BnMulFusionPass())
            optimizer.add_pass(opt.BnAddFusionPass())
            optimizer.add_pass(opt.ConvBnFusionPass())
        # fusion info
        optimizer.add_pass(opt.SetFusionInfoPass())
        optimizer.do_optimizer(graph)

    def summary(self):
        """Summarize and output the final result information."""
        PerfBasedAutoCalibrationBase.summary(self)
        best_deploy_onnx_file = self.iter_recorder.recorders[
            self.best_iter_num][PB_FILE]
        best_fakequant_onnx_file = ''.join([best_deploy_onnx_file[:-5], '_fake_quant_model.onnx'])
        best_config_file = ''.join([best_deploy_onnx_file[:-4], 'json'])
        best_record_file = ''.join([best_deploy_onnx_file[:-4], 'txt'])
        best_pb_json_file = ''.join([best_deploy_onnx_file[:-5], '_quant.json'])

        deploy_onnx_file = generate_onnx_file_name(self.save_dir, self.prefix_name, 'Deploy')
        fake_quant_onnx_file = generate_onnx_file_name(self.save_dir, self.prefix_name, 'FakeQuant')
        config_file = os.path.join(
            self.save_dir, 'perf_based_auto_calibration_final_config.json')
        record_file = os.path.join(self.save_dir, 'record.txt')
        pb_json_file = ''.join([deploy_onnx_file[:-5], '.json'])
        check_files_exist([deploy_onnx_file, fake_quant_onnx_file, config_file, record_file, pb_json_file])
        shutil.copy(best_deploy_onnx_file, deploy_onnx_file)
        if os.path.exists(best_pb_json_file):
            shutil.copy(best_fakequant_onnx_file, fake_quant_onnx_file)
            shutil.copy(best_config_file, config_file)
            shutil.copy(best_record_file, record_file)
            shutil.copy(best_pb_json_file, pb_json_file)
            LOGGER.logi(
                'The generated deploy model is stored in dir: {}.'.format(deploy_onnx_file))
            LOGGER.logi(
                'The generated fakequant model is stored in dir: {}.'.format(fake_quant_onnx_file))
            LOGGER.logi(
                'The records file is stored in dir: {}.'.format(record_file))
        else:
            LOGGER.logi(
                'The best performance model is the unquantified model.')
        fusion_result = os.path.realpath('./fusion_result.json')
        PerfBasedAutoCalibration.clean_tmp(fusion_result)
        kernel_meta = os.path.realpath('./kernel_meta')
        PerfBasedAutoCalibration.clean_tmp(kernel_meta)


@check_params(original_model_file=str,
              quantized_model_file=str,
              sampler_config_file=str,
              save_dir=str)
def perf_based_auto_calibration(original_model_file,
                                quantized_model_file,
                                sampler_config_file,
                                save_dir,
                                strategy='BatchRollBack'):
    """
    Function: Based on the model, the performance of the upper plate is
              automatically quantized, and a better mixed precision
              quantization model is obtained.
    Inputs:
        original_model_file: Original unquantified model.
        quantized_model_file: Quantitative model.
        sampler_config_file: .
        save_dir: performance sampling profile.
        strategy: performance based quantitative backoff strategy.
    Returns: None.
    """
    # Check input parameters
    is_valid_name(original_model_file, 'model')
    original_model_file = os.path.realpath(original_model_file)
    is_valid_name(quantized_model_file, 'model')
    quantized_model_file = os.path.realpath(quantized_model_file)
    is_valid_name(sampler_config_file, 'sampler_config_file')
    sampler_config_file = os.path.realpath(sampler_config_file)
    save_dir = os.path.realpath(save_dir)

    if strategy == 'BatchRollBack':
        strategy = BatchRollBackStrategy()
    else:
        if not isinstance(strategy, PerfStrategyBase):
            raise RuntimeError("'strategy' is not inherited from base class StrategyBase!")

    # Define auto calibration class
    auto_calibration_controller = PerfBasedAutoCalibration(
        [original_model_file, quantized_model_file], sampler_config_file,
        save_dir, strategy)

    auto_calibration_controller.run()
